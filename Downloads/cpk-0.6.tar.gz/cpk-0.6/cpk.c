/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * You can obtain a copy of the license at /LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/**
 * CPK (Combined Public Key) Toolkit
 *	Version: 0.6.8
 *	Author:  Guan, Zhi <guanzhi@infosec.pku.edu.cn>
 *
 * Copyright 2007. All rights reserved. 
 * Use is subject to license terms.
 */


typedef unsigned int uint32_t;


// ----- FILE KDF.H BEGIN
#include <openssl/evp.h>

typedef void *(*KDF)(const void *in, size_t inlen, void *out, size_t *outlen);

KDF x9_63_kdf_md(const EVP_MD *md);
int x9_63_kdf(const EVP_MD *md, const unsigned char *share, size_t sharelen, 
              size_t keylen, unsigned char *outkey);

// FILE KDF.H END


// ----- CONFIG ---------------------------------------------------------------
#define CONF_CURVENAME		"secp192k1"
//#define CONF_MAPALGO		"MAP-SHA1"

#define RELEASE_VERSION		"0.6.8"
#define DEVELOP_VERSION		" " 
#define RELEASE_TIME		__DATE__ " " __TIME__	
#define OPENSSL_VERSION		"OpenSSL 0.9.8e"

#define STR_ERROR_FILELINE	"%s(%d):"
#define STR_ERROR_OPENFILE	"open file %s failed "STR_ERROR_FILELINE
#define STR_ERROR_INVALPARAMS	"parameters invalid "STR_ERROR_FILELINE
#define STR_ERROR_OPTION	"option %s invalid\n" 
#define STR_ERROR_READFILE	"read file %s error "STR_ERROR_FILELINE

#ifndef _WIN32
#include <unistd.h>
#endif

#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/asn1.h>
#include <openssl/asn1t.h>
#include <openssl/hmac.h>
#include <openssl/ecdh.h>
#include <openssl/ecdsa.h>

#define CPK_VERSION		1
#define MATRIX_ID_MAX_SIZE	10
#define EC_POINT_FORMAT		4
#define ECIES_MAX_SIZE		4096
#define ECIES_MAX_PLAINTEXT	4096


unsigned char *ASN1_new_buffer_by_fp(FILE *fp, size_t *len);
char *ASN1_new_buffer_by_string(ASN1_STRING *asn1);

typedef struct matrix_st {
	long			ver;
	ASN1_UTF8STRING		*id;
	long			col;
	long			row;
	ASN1_OBJECT		*mapoid;	
	ASN1_OBJECT		*ecoid;
	ASN1_OCTET_STRING	*data;
} MATRIX;
typedef struct matrix_st PUBMATRIX;
typedef struct matrix_st PRIVMATRIX;
DECLARE_ASN1_FUNCTIONS(MATRIX);

typedef struct privkey_st {
	long			ver;
	ASN1_OBJECT		*ecoid;
	ASN1_UTF8STRING		*matrixid;
	ASN1_UTF8STRING		*keyid;
	ASN1_INTEGER		*keydata;
} PRIVKEY;
DECLARE_ASN1_FUNCTIONS(PRIVKEY);

typedef struct siginfo_st {
	long			ver;
	ASN1_UTF8STRING		*matrixid;
	ASN1_UTF8STRING		*signerid;
	ASN1_OBJECT		*mdoid;
	ASN1_OCTET_STRING	*sigvalue;
} SIGINFO;
DECLARE_ASN1_FUNCTIONS(SIGINFO);

typedef struct rcptinfo_st {
	long			ver;
	ASN1_UTF8STRING		*matrixid;
	ASN1_UTF8STRING		*rcptid;
	ASN1_OBJECT		*kdfmd;
	ASN1_OBJECT		*encalg;
	ASN1_OBJECT		*macalg;
	ASN1_OCTET_STRING	*ecpoint;
	ASN1_OCTET_STRING	*enceddata;
	ASN1_OCTET_STRING	*macdata;
} RCPTINFO;
DECLARE_ASN1_FUNCTIONS(RCPTINFO);

// ----- MATRIX FUNCTIONS -----
int MATRIX_is_valid(const MATRIX *matrix, int is_primat);
const EVP_MD *MATRIX_get_map_md(const MATRIX *matrix);
EC_GROUP *MATRIX_get_ecgroup(const MATRIX *matrix);


// ----- PRIVATE MATRIX FUNCTIONS -----
MATRIX *PRIVMATRIX_create(const EC_GROUP *ec_group, int col, int row, const EVP_MD *md);
#define PRIVMATRIX_is_valid(m) MATRIX_is_valid(m,1)
#define	PRIVMATRIX_get_map_md(m) MATRIX_get_map_md(m)
#define PRIVMATRIX_get_ecgroup(m) MATRIX_get_ecgroup(m)
BIGNUM *PRIVMATRIX_get_bnkey(const PRIVMATRIX *matrix, const char *keyid, unsigned int keyidlen);
EC_KEY *PRIVMATRIX_get_eckey(const PRIVMATRIX *matrix, const char *keyid, unsigned int keyidlen);
PUBMATRIX *PRIVMATRIX_gen_pubmat(const PRIVMATRIX *primat);
PRIVKEY *PRIVMATRIX_gen_privkey(const PRIVMATRIX *matrix, const char *keyid, unsigned int keyidlen);

// ----- PUBLIC MATRIX FUNCTIONS -----
#define PUBMATRIX_is_valid(m)	MATRIX_is_valid(m,0)
#define PUBMATRIX_get_map_md(m) MATRIX_get_map_md(m)
#define PUBMATRIX_get_ecgroup(m) MATRIX_get_ecgroup(m)
EC_POINT *PUBMATRIX_get_ptkey(const PUBMATRIX *matrix, const char *keyid, unsigned int keyidlen);
EC_KEY *PUBMATRIX_get_eckey(const PUBMATRIX *matrix, const char *keyid, unsigned int keyidlen);

// ----- PRIVATE KEY FUNCTIONS -----
EC_GROUP *PRIVKEY_get_ecgroup(const PRIVKEY *privkey);
EC_KEY *PRIVKEY_get_eckey(const PRIVKEY *privkey);


// ----- MATCH FUNCTIONS -----
int PUBMATRIX_match_privmatrix(const PUBMATRIX *pubmat, const PRIVMATRIX *primat);
int PRIVKEY_match_pubmatrix(const PRIVKEY *privkey, const PUBMATRIX *pubmat);
int PRIVKEY_match_privmatrix(const PRIVKEY *privkey, const PRIVMATRIX *primat);
int SIGINFO_match_pubmatrix(const SIGINFO *siginfo, const PUBMATRIX *pubmat);
int RCPTINFO_match_privkey(const RCPTINFO *rcptinfo, const PRIVKEY *privkey);



// ----- SIGNER INFO FUNCTIONS -----
const EVP_MD *SIGINFO_get_md(const SIGINFO *siginfo);


// ----- RECIPIENT INFO FUNCTIONS -----
const EVP_MD *RCPTINFO_get_kdf_md(const RCPTINFO *rcptinfo);
KDF RCPTINFO_get_kdf(const RCPTINFO *rcptinfo);
const EVP_CIPHER *RCPTINFO_get_cipher(const RCPTINFO *rcptinfo);
const EVP_MD *RCPTINFO_get_hmac_md(const RCPTINFO *rcptinfo);
EC_POINT *RCPTINFO_get_ecpoint(const RCPTINFO *rcptinfo, const EC_GROUP *ec_group);

// ----- SIGN/VERIFY ENCRYPT/DECRYPT -----
SIGINFO *PRIVKEY_sign(const PRIVKEY *privkey, const EVP_MD *md, 
		      const unsigned char *dgst, unsigned int dgstlen);
int PRIVKEY_decrypt(const PRIVKEY *privkey, const RCPTINFO *rcptinfo, 
		    unsigned char *out, size_t *outlen);
RCPTINFO *PUBMATRIX_encrypt(const PUBMATRIX *pubmat, const char *rcptid, 
			    unsigned int rcptidlen, const EVP_MD *kdf_md, 
			    const EVP_CIPHER *cipher, const EVP_MD *hmac_md,
			    const unsigned char *data, size_t datalen);
int PUBMATRIX_verify(const PUBMATRIX *pubmat, const unsigned char *dgst, 
		     unsigned int dgstlen, const SIGINFO *siginfo);

// ----- ASN.1 PRINT FUNCTIONS -----
int MATRIX_print(const MATRIX *matrix, FILE *outfp, int flag);
int PRIVKEY_print(const PRIVKEY *privkey, FILE *outfp, int flag);
int SIGINFO_print(const SIGINFO *siginfo, FILE *outfp, int flag);
int RCPTINFO_print(const RCPTINFO *rcptinfo, FILE *outfp, int flag);

// ----- ASN.1 IS_VALID FUNCTIONS -----
int MATRIX_is_valid(const MATRIX *matrix, int is_primat);
int PRIVKEY_is_valid(const PRIVKEY *privkey);
int SIGINFO_is_valid(const SIGINFO *siginfo);
int RCPTINFO_is_valid(const RCPTINFO *rcptinfo, const EC_GROUP *ec_group);

// ----- ASN.1 I2F, F2I, I2FP, FP2I FUCNTIONS -----
int i2fp_MATRIX(MATRIX *matrix, FILE *fp);
int i2fp_PRIVKEY(PRIVKEY *privkey, FILE *fp);
int i2fp_SIGINFO(SIGINFO *siginfo, FILE *fp);
int i2fp_RCPTINFO(RCPTINFO *rcptinfo, FILE *fp);

int i2f_MATRIX(MATRIX *matrix, const char *file);
int i2f_PRIVKEY(PRIVKEY *privkey, const char *file);
int i2f_SIGINFO(SIGINFO *siginfo, const char *file);
int i2f_RCPTINFO(RCPTINFO *rcptinfo, const char *file);

MATRIX *fp2i_MATRIX(FILE *fp);
PRIVKEY *fp2i_PRIVKEY(FILE *fp);
SIGINFO *fp2i_SIGINFO(FILE *fp);
RCPTINFO *fp2i_RCPTINFO(FILE *fp);

MATRIX *f2i_MATRIX(const char *file);
PRIVKEY *f2i_PRIVKEY(const char *file);
SIGINFO *f2i_SIGINFO(const char *file);
RCPTINFO *f2i_RCPTINFO(const char *file);

// ----- FILE FUNCTIONS BEGIN -----
long filesize(const char *filename);
unsigned char *file2buffer(const char *filename);

long filesize(const char *filename)
{
	struct stat file;
	
	if (!stat(filename, &file))
		return file.st_size;
	
	return -1;
}


unsigned char *file2buffer(const char *filename)
{
	int ok = 0;
	FILE *fp = NULL;
	unsigned char *buf = NULL;
	size_t len;
	
	if (!(fp = fopen(filename, "rb")))
	{
		fprintf(stderr, "fopen( %s ) failed:", filename);
		goto end;
	}

	if ((len = filesize(filename)) <= 0)
	{
		fprintf(stderr, "filesize( %s ) error:", filename);
		goto end;
	}
		
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	
	if (fread(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	ok = 1;

end:
	if (!ok && buf)
	{
		OPENSSL_free(buf);
		buf = NULL;
	}

	if (fp) fclose(fp);

	return buf;	
}
// ----- FILE FUNCTIONS END -----




// ----- KDF BODY -----
static void *x9_63_kdf_md5(const void *in, size_t inlen, void *out, size_t *outlen);
static void *x9_63_kdf_ripemd160(const void *in, size_t inlen, void *out, size_t *outlen);
static void *x9_63_kdf_sha1(const void *in, size_t inlen, void *out, size_t *outlen);	      
static void *x9_63_kdf_sha224(const void *in, size_t inlen, void *out, size_t *outlen);
static void *x9_63_kdf_sha256(const void *in, size_t inlen, void *out, size_t *outlen);
static void *x9_63_kdf_sha384(const void *in, size_t inlen, void *out, size_t *outlen);
static void *x9_63_kdf_sha512(const void *in, size_t inlen, void *out, size_t *outlen);

int x9_63_kdf(const EVP_MD *md, const unsigned char *share, size_t sharelen, 
	      size_t keylen, unsigned char *outkey)
{
	int ret = 0;

	EVP_MD_CTX ctx;	
	unsigned char counter[4] = {0, 0, 0, 1};
	unsigned char dgst[EVP_MAX_MD_SIZE];
	unsigned int dgstlen;
	int rlen = (int)keylen;
	
	if ((int)keylen > EVP_MD_size(md)*255)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	while (rlen > 0)  
	{
		EVP_MD_CTX_init(&ctx);
		
		if (!EVP_DigestInit(&ctx, md))
		{
			fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
			goto end;
		}
		
		if (!EVP_DigestUpdate(&ctx, share, sharelen)) 
		{
			fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
			goto end;
		}
		if (!EVP_DigestUpdate(&ctx, counter, 4)) 
		{
			fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
			goto end;
		}
		if (!EVP_DigestFinal(&ctx, dgst, &dgstlen)) 
		{
			fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
			goto end;
		}
		
		EVP_MD_CTX_cleanup(&ctx);
	
		
		memcpy(outkey, dgst, rlen<dgstlen ? rlen : dgstlen); // this bug has been fixed.
		
		rlen -= dgstlen;
		outkey += dgstlen;
		counter[3]++;
	}


	ret = 1;

end:
	return ret;
}



static void *x9_63_kdf_md5(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_md5(), in, inlen, *outlen, out))
		return out;

	return NULL;
}


static void *x9_63_kdf_ripemd160(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_ripemd160(), in, inlen, *outlen, out))
		return out;

	return NULL;
}

static void *x9_63_kdf_sha1(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_sha1(), in, inlen, *outlen, out))
		return out;

	return NULL;
}

static void *x9_63_kdf_sha224(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_sha224(), in, inlen, *outlen, out))
		return out;

	return NULL;
}

static void *x9_63_kdf_sha256(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_sha256(), in, inlen, *outlen, out))
		return out;

	return NULL;
}

static void *x9_63_kdf_sha384(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_sha384(), in, inlen, *outlen, out))
		return out;

	return NULL;
}

static void *x9_63_kdf_sha512(const void *in, size_t inlen, void *out, size_t *outlen)
{
	if (x9_63_kdf(EVP_sha512(), in, inlen, *outlen, out))
		return out;

	return NULL;
}

KDF x9_63_kdf_md(const EVP_MD *md)
{
		
	if 	(md == EVP_md5())
		return x9_63_kdf_md5;
	else if (md == EVP_ripemd160())
		return x9_63_kdf_ripemd160;
	else if (md == EVP_sha1())	
		return x9_63_kdf_sha1;
	else if (md == EVP_sha224())	
		return x9_63_kdf_sha224;
	else if (md == EVP_sha256())
		return x9_63_kdf_sha256;
	else if (md == EVP_sha384())
		return x9_63_kdf_sha384;
	else if (md == EVP_sha512())
		return x9_63_kdf_sha512;
	
	return NULL;
}
// ----- KDF END -----


// ----- ASN1 FUNCTIONS BEGIN -----
ASN1_SEQUENCE(MATRIX) = {
	ASN1_SIMPLE(MATRIX, ver, LONG),
	ASN1_SIMPLE(MATRIX, id, ASN1_UTF8STRING),
	ASN1_SIMPLE(MATRIX, col, LONG),
	ASN1_SIMPLE(MATRIX, row, LONG),
	ASN1_SIMPLE(MATRIX, mapoid, ASN1_OBJECT),	
	ASN1_SIMPLE(MATRIX, ecoid, ASN1_OBJECT),
	ASN1_SIMPLE(MATRIX, data, ASN1_OCTET_STRING),
} ASN1_SEQUENCE_END(MATRIX);
IMPLEMENT_ASN1_FUNCTIONS(MATRIX);

ASN1_SEQUENCE(PRIVKEY) = {
	ASN1_SIMPLE(PRIVKEY, ver, LONG),
	ASN1_SIMPLE(PRIVKEY, ecoid, ASN1_OBJECT),
	ASN1_SIMPLE(PRIVKEY, matrixid, ASN1_UTF8STRING),
	ASN1_SIMPLE(PRIVKEY, keyid, ASN1_UTF8STRING),
	ASN1_SIMPLE(PRIVKEY, keydata, ASN1_INTEGER),
} ASN1_SEQUENCE_END(PRIVKEY);
IMPLEMENT_ASN1_FUNCTIONS(PRIVKEY);

ASN1_SEQUENCE(SIGINFO) = {
	ASN1_SIMPLE(SIGINFO, ver, LONG),
	ASN1_SIMPLE(SIGINFO, matrixid, ASN1_UTF8STRING),
	ASN1_SIMPLE(SIGINFO, signerid, ASN1_UTF8STRING),
	ASN1_SIMPLE(SIGINFO, mdoid, ASN1_OBJECT),	
	ASN1_SIMPLE(SIGINFO, sigvalue, ASN1_OCTET_STRING),
} ASN1_SEQUENCE_END(SIGINFO);
IMPLEMENT_ASN1_FUNCTIONS(SIGINFO);

ASN1_SEQUENCE(RCPTINFO) = {
	ASN1_SIMPLE(RCPTINFO, ver, LONG),
	ASN1_SIMPLE(RCPTINFO, matrixid, ASN1_UTF8STRING),
	ASN1_SIMPLE(RCPTINFO, rcptid, ASN1_UTF8STRING),
	ASN1_SIMPLE(RCPTINFO, kdfmd, ASN1_OBJECT),
	ASN1_SIMPLE(RCPTINFO, encalg, ASN1_OBJECT),	
	ASN1_SIMPLE(RCPTINFO, macalg, ASN1_OBJECT),
	ASN1_SIMPLE(RCPTINFO, ecpoint, ASN1_OCTET_STRING),
	ASN1_SIMPLE(RCPTINFO, enceddata, ASN1_OCTET_STRING),
	ASN1_SIMPLE(RCPTINFO, macdata, ASN1_OCTET_STRING)
} ASN1_SEQUENCE_END(RCPTINFO);
IMPLEMENT_ASN1_FUNCTIONS(RCPTINFO);
// ----- ASN1 FUNCTIONS END -----

// ----- MATRIX STATIC FUNCTIONS BEGIN ----- 
static int is2pow(unsigned int n);
static int log2n(unsigned int n);
static int colrowmap_is_valid(int col, int row, const EVP_MD *map_md);
static int str2index(const EVP_MD *md, int col, int row, const char *str, unsigned int slen, int index[]);
static int gen_matrix_id(const unsigned char *data, size_t datalen, char *id, unsigned int *idlen);

static int is2pow(unsigned int n)
{
	do if (n%2) return 0;
	while ((n = n/2) > 1); 

	return 1;
}

static int log2n(unsigned int n)
{
	int r = 0;
	while (n = n/2)
		r++;
	
	return r;
}	
	
static int colrowmap_is_valid(int col, int row, const EVP_MD *map_md)
{
	if (col < 4 || row < 4)
		return 0;

	if (!is2pow(row))
		return 0;

	if ((log2n(row) * col) > (EVP_MD_size(map_md)*8))
		return 0;

	return 1;
}

static int str2index(const EVP_MD *md, int col, int row, const char *str, unsigned int slen, int index[]) 
{
	int ret = 0;
	int i;
	
	unsigned char dgst[EVP_MAX_MD_SIZE];
	unsigned int dgstlen;
	BIGNUM *bn = BN_new();
	
	if (!bn) 
		return 0;
	
	if (!EVP_Digest(str, slen, dgst, &dgstlen, md, NULL))
	{
		fprintf(stderr, "EVP_Digest():");
		goto err;
	}
	if (!BN_bin2bn(dgst, dgstlen, bn))
	{
		fprintf(stderr, "BN_bin2bn():");
		goto err;
	}
	
	for (i=0; i<col; i++)
	{
		//FIXME
		int r = BN_div_word(bn, row);
		index[col-i-1] = r + row * (col-i-1);
		//printf("%d   bn=%s\n, r=%d, index=%d\n", i, BN_bn2hex(bn), r, index[col-i-1]);  
	}
	ret = 1;
err:
	if (!bn) BN_free(bn);
	return ret; 
}


// FIXME: this function return different results on different platform (PPC64 & I386)
static int gen_matrix_id(const unsigned char *data, size_t datalen, char *id, unsigned int *idlen)
{
	int i;
	const EVP_MD *md = EVP_sha1();
	unsigned char dgst[EVP_MAX_MD_SIZE];
	unsigned int dgstlen;
	uint32_t *p = (uint32_t *)dgst;
	uint32_t r = 0;
	char *c = (char *)&r;

	if (!data || datalen <=0 || !id || !idlen)
	{
		return 0;
	}		
	

	if (!EVP_Digest(data, datalen, dgst, &dgstlen, md, NULL)) 
	{
		return 0;
	}
	
	for (i=0; i<dgstlen/4; i++)
		r ^= *p++;

	for (i=0; i<4; i++)
		sprintf(id+i*2, "%2X", *c++);

	*idlen = 8; // hex size of a uint32_t // TOFIX

	return 1;	
}
// ----- MATRIX STATIC FUNCTIONS END -----


// ----- MATRIX FUNCTIONS BEGIN -----



const EVP_MD *MATRIX_get_map_md(const MATRIX *matrix)
{
	OpenSSL_add_all_digests();
	return EVP_get_digestbynid(OBJ_obj2nid(matrix->mapoid));
}

EC_GROUP *MATRIX_get_ecgroup(const MATRIX *matrix)
{
	return EC_GROUP_new_by_curve_name(OBJ_obj2nid(matrix->ecoid));
}
// ----- MATRIX FUNCTIONS END -----



// ----- PRIVATE MATRIX FUNCTIONS BEGIN -----
PRIVMATRIX *PRIVMATRIX_create(const EC_GROUP *ec_group, int col, int row, const EVP_MD *md)
{
	int ok = 0;
	MATRIX *matrix = MATRIX_new();

	int i;
	BIGNUM *bn = BN_new();
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();
	EC_POINT *pt = NULL;
	int bnlen;
	char *id = (char *)OPENSSL_malloc(MATRIX_ID_MAX_SIZE);
	unsigned int idlen;
	unsigned char *data = NULL;
	unsigned int datalen;
	unsigned char *p;

	if (!ec_group || !md)
	{
		goto end;
	}

	if (!matrix || !bn || !order || !ctx || !id)
	{
		goto end;
	}
	
	EC_GROUP_get_order(ec_group, order, ctx);
	bnlen = BN_num_bytes(order);
	datalen = bnlen * col * row;
	data = (unsigned char *)OPENSSL_malloc(datalen);
	memset(data, 0, datalen);

	p = data;
	for (i=0; i<col*row; i++) 
	{
		BN_rand_range(bn, order);
		BN_bn2bin(bn, p + bnlen - BN_num_bytes(bn));
		p += bnlen;
	}

	gen_matrix_id(data, datalen, id, &idlen);

	// set private matrix		
	matrix->ver = CPK_VERSION;
	ASN1_STRING_set((ASN1_STRING *)matrix->id, id, idlen); 
	matrix->col = col;
	matrix->row = row;
	ASN1_OBJECT_free(matrix->mapoid);
	matrix->mapoid = OBJ_nid2obj(EVP_MD_nid(md));
	ASN1_OBJECT_free(matrix->ecoid);
	matrix->ecoid = OBJ_nid2obj(EC_GROUP_get_curve_name(ec_group));
	ASN1_OCTET_STRING_set(matrix->data, data, datalen); 


	ok = 1;
end:
	if (!ok && matrix) 
	{
		MATRIX_free(matrix);
		matrix = NULL;
	}

	if (bn)	BN_free(bn);
	if (order) BN_free(order);
	if (ctx) BN_CTX_free(ctx);
	if (pt) EC_POINT_free(pt);	

	// FIXME: id and data should be checked, if err, they should be cleared

	return matrix;
}

BIGNUM *PRIVMATRIX_get_bnkey(const PRIVMATRIX *matrix, const char *keyid, unsigned int keyidlen)
{
	BIGNUM *ret = BN_new();

	int i;
	int ok = 0;

	EC_GROUP *ec_group = NULL;
	BIGNUM *bn = BN_new();
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();
	int bnlen;
	unsigned char *pbn = ASN1_STRING_data(matrix->data);

	int *index = NULL;
	const EVP_MD *md;

	
	if (!(ec_group = PRIVMATRIX_get_ecgroup(matrix)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}
	
	if (!EC_GROUP_get_order(ec_group, order, ctx))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}
	
	bnlen = BN_num_bytes(order);

	if (!(index = (int *)OPENSSL_malloc(sizeof(int) * matrix->col)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}	

	if (!(md = PRIVMATRIX_get_map_md(matrix)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}	
	
	str2index(md, matrix->col, matrix->row, keyid, keyidlen, index);
	
	
	BN_zero(ret);
	for (i=0; i<matrix->col; i++)
	{
		pbn = ASN1_STRING_data(matrix->data) + bnlen * index[i];
		BN_bin2bn(pbn, bnlen, bn);
		BN_mod_add(ret, ret, bn, order, ctx);
	}

	ok = 1;	
end:
	if (ec_group) EC_GROUP_free(ec_group);
	if (bn) BN_free(bn);
	if (order) BN_free(order);
	if (ctx) BN_CTX_free(ctx);
	if (index) OPENSSL_free(index);
	
	if (!ok && ret) 
	{
		BN_free(ret);
		ret = NULL;
	}

	return ret;	
}

EC_KEY *PRIVMATRIX_get_eckey(const PRIVMATRIX *matrix, const char *keyid, unsigned int keyidlen)
{
	int ok = 0;
	
	EC_KEY *ec_key = EC_KEY_new();
	EC_GROUP *ec_group = NULL;
	BIGNUM *bn = NULL;	

	if (!ec_key)
		return NULL;

	if (!(ec_group = PRIVMATRIX_get_ecgroup(matrix)))
		{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
		}	

	if (!EC_KEY_set_group(ec_key, ec_group))
		{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
		}

	if (!(bn = PRIVMATRIX_get_bnkey(matrix, keyid, keyidlen)))
		{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
		}

	if (!EC_KEY_set_private_key(ec_key, bn))
		{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
		}

	ok = 1;

end:
	if (!ok && ec_key)
		{
		EC_KEY_free(ec_key);
		ec_key = NULL;
		}

	if (ec_group) EC_GROUP_free(ec_group);
	if (bn) BN_free(bn);	

	return ec_key;
} 
PUBMATRIX *PRIVMATRIX_gen_pubmat(const PRIVMATRIX *primat)
{
	int ok = 0;
	MATRIX *public_matrix = MATRIX_new();

	int i;
	EC_GROUP *ec_group = NULL;
	BIGNUM *bn = BN_new();
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();
	EC_POINT *pt = NULL;
	unsigned char *pbn, *ppt;
	unsigned int bnlen, ptlen;
	unsigned char *data = NULL;
	unsigned int datalen;
	unsigned char ptbuf[128];

	if (!public_matrix || !bn || !order || !ctx)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!PRIVMATRIX_is_valid(primat))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ec_group = EC_GROUP_new_by_curve_name(OBJ_obj2nid(primat->ecoid));
	pt = EC_POINT_new(ec_group);

	EC_GROUP_get_order(ec_group, order, ctx);
	bnlen = BN_num_bytes(order);
	ptlen = bnlen * 2;
	
	datalen = 1 + ptlen * primat->col * primat->row;
	data = (unsigned char *)OPENSSL_malloc(datalen);
	data[0] = 4;

	pbn = ASN1_STRING_data(primat->data);
	ppt = data + 1;
			
	for (i=0; i<primat->col * primat->row; i++)
	{
		BN_bin2bn(pbn, bnlen, bn);
		if (BN_cmp(bn, order) >= 0)
		{
			// decoded private key overflow (bn MUST < order)
			goto end;
		}
	
		EC_POINT_mul(ec_group, pt, bn, NULL, NULL, ctx);
		EC_POINT_point2oct(ec_group, pt, 4, ptbuf, ptlen+1, ctx);
		memcpy(ppt, ptbuf+1, ptlen);
		
		pbn += bnlen;
		ppt += ptlen;
	}

	//FIXME
	//gen_matrix_id(data + 1, datalen - 1, id, &idlen);

	// set public matrix 
	public_matrix->ver = primat->ver;
	ASN1_STRING_set(public_matrix->id, primat->id->data, primat->id->length);
	public_matrix->col = primat->col;
	public_matrix->row = primat->row;
	ASN1_OBJECT_free(public_matrix->ecoid);
	public_matrix->ecoid = OBJ_nid2obj(OBJ_obj2nid(primat->ecoid));
	ASN1_OBJECT_free(public_matrix->mapoid);
	public_matrix->mapoid = OBJ_nid2obj(OBJ_obj2nid(primat->mapoid));	
	ASN1_STRING_set(public_matrix->data, data, datalen);

	ok = 1;
end:
	if (!ok && public_matrix)
	{
		MATRIX_free(public_matrix);
		public_matrix = NULL;
	}

	if (ec_group) EC_GROUP_free(ec_group);
	if (bn) BN_free(bn);
	if (order) BN_free(order);
	if (ctx) BN_CTX_free(ctx);
	if (pt) EC_POINT_free(pt);
	if (data) OPENSSL_free(data);

	return public_matrix;
}

PRIVKEY *PRIVMATRIX_gen_privkey(const PRIVMATRIX *matrix, const char *keyid, unsigned int keyidlen)
{
	PRIVKEY *asn1_privkey = PRIVKEY_new();

	int ok = 0;
	BIGNUM *bn = NULL;
	unsigned char *matrixid;
	unsigned int matrixidlen;
	
	if (!asn1_privkey || !matrix || !keyid || keyidlen<=0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!PRIVMATRIX_is_valid(matrix))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	matrixid = ASN1_STRING_data(matrix->id);
	matrixidlen = ASN1_STRING_length(matrix->id);

	if (!(bn = PRIVMATRIX_get_bnkey(matrix, keyid, keyidlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	// set cert
	asn1_privkey->ver = 1;
	ASN1_OBJECT_free(asn1_privkey->ecoid);
	if (!(asn1_privkey->ecoid = OBJ_nid2obj(OBJ_obj2nid(matrix->ecoid))))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!ASN1_STRING_set(asn1_privkey->matrixid, matrixid, matrixidlen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!ASN1_STRING_set(asn1_privkey->keyid, keyid, keyidlen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!BN_to_ASN1_INTEGER(bn, asn1_privkey->keydata))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ok = 1;

end:
	if (!ok && asn1_privkey)
	{
		PRIVKEY_free(asn1_privkey);
		asn1_privkey = NULL;
	}

	if (bn) BN_free(bn);

	return asn1_privkey; 
}
// ----- PRIVATE MATRIX FUNCTIONS END -----


// ----- PUBLIC MATRIX FUNCTIONS BEGIN -----
EC_POINT *PUBMATRIX_get_ptkey(const PUBMATRIX *matrix, const char *keyid, unsigned int keyidlen)
{
	EC_POINT *ret = NULL;
	
	int i;
	int ok = 0;

	EC_GROUP *ec_group = NULL;
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();
	EC_POINT *pt = NULL;

	int bnlen, ptlen;
	unsigned char ptbuf[128];

	int *index = NULL;
	const EVP_MD *md;

	if (!matrix || !keyid || keyidlen<=0)
	{
		goto end;
	}

	if (!PUBMATRIX_is_valid(matrix))
	{
		goto end;
	}

	
	ec_group = EC_GROUP_new_by_curve_name(OBJ_obj2nid(matrix->ecoid));
	EC_GROUP_get_order(ec_group, order, ctx);
	bnlen = BN_num_bytes(order);
	ptlen = bnlen * 2;
	ret = EC_POINT_new(ec_group);
	pt = EC_POINT_new(ec_group);



	index = (int *)OPENSSL_malloc(sizeof(int) * matrix->col);
	OpenSSL_add_all_digests();
	md = EVP_get_digestbynid(OBJ_obj2nid(matrix->mapoid));
	str2index(md, matrix->col, matrix->row, keyid, keyidlen, index);
		

	EC_POINT_set_to_infinity(ec_group, ret);
	ptbuf[0] = 4;
	for (i=0; i<matrix->col; i++)
	{
		memcpy(ptbuf+1, ASN1_STRING_data(matrix->data) + 1 + ptlen*index[i], ptlen);
		EC_POINT_oct2point(ec_group, pt, ptbuf, ptlen + 1, ctx);
		EC_POINT_add(ec_group, ret, ret, pt, ctx);
	}
		
	ok = 1;	
end:
	if (ec_group) EC_GROUP_free(ec_group);
	if (order) BN_free(order);
	if (ctx) BN_CTX_free(ctx);
	if (pt) EC_POINT_free(pt);
	if (index) OPENSSL_free(index);

	if (!ok && ret) 
	{
		EC_POINT_free(ret);
		ret = NULL;
	}

	return ret;	
}

EC_KEY *PUBMATRIX_get_eckey(const PUBMATRIX *matrix, const char *keyid, unsigned int keyidlen)
{
	int ok = 0;

	EC_KEY *ec_key = EC_KEY_new();
	EC_GROUP *ec_group = NULL;
	EC_POINT *pt = NULL;

	if (!ec_key || !matrix || !keyid)
	{
		return NULL;
	}

	if (!(ec_group = PUBMATRIX_get_ecgroup(matrix)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!EC_KEY_set_group(ec_key, ec_group))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(pt = PUBMATRIX_get_ptkey(matrix, keyid, keyidlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!EC_KEY_set_public_key(ec_key, pt))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ok = 1;

end:
	if (!ok && ec_key)
	{
		EC_KEY_free(ec_key);
		ec_key = NULL;
	}

	if (ec_group) EC_GROUP_free(ec_group);
	if (pt)	EC_POINT_free(pt);

	return ec_key;
}
// ----- PUBLIC MATRIX FUNCTIONS END -----


// ----- PRIVATE KEY FUNCTIONS BEGIN -----
EC_GROUP *PRIVKEY_get_ecgroup(const PRIVKEY *privkey)
{
	return EC_GROUP_new_by_curve_name(OBJ_obj2nid(privkey->ecoid));
}
	
EC_KEY *PRIVKEY_get_eckey(const PRIVKEY *privkey)
{
        EC_KEY *ec_key = EC_KEY_new();

        int ok = 0;
        EC_GROUP *ec_group = NULL;
        BIGNUM *bn = BN_new();
        BN_CTX *ctx = BN_CTX_new();
        EC_POINT *pt = NULL;

        if (!privkey || !ec_key)
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!(ec_group = EC_GROUP_new_by_curve_name(OBJ_obj2nid(privkey->ecoid))))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!ASN1_INTEGER_to_BN(privkey->keydata, bn))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!(pt = EC_POINT_new(ec_group)))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!EC_POINT_mul(ec_group, pt, bn, NULL, NULL, ctx))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!EC_KEY_set_group(ec_key, ec_group))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!EC_KEY_set_private_key(ec_key, bn))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!EC_KEY_set_public_key(ec_key, pt))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        if (!EC_KEY_check_key(ec_key))
        {
                fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
                goto end;
        }

        ok = 1;

end:
        if (!ok && ec_key)
        {
                EC_KEY_free(ec_key);
                ec_key = NULL;
        }

        if (ec_group) EC_GROUP_free(ec_group);
        if (bn) BN_free(bn);
        if (ctx) BN_CTX_free(ctx);
        if (pt) EC_POINT_free(pt); 

        return ec_key;

}
// ----- PRIVATE KEY FUNCTIONS END -----

// ----- MATCH FUNCTIONS BEGIN -----
int PUBMATRIX_match_privmatrix(const PUBMATRIX *pubmat, const PRIVMATRIX *primat);
int PRIVKEY_match_pubmatrix(const PRIVKEY *privkey, const PUBMATRIX *pubmat);
int PRIVKEY_match_privmatrix(const PRIVKEY *privkey, const PRIVMATRIX *primat);
int SIGINFO_match_pubmatrix(const SIGINFO *siginfo, const PUBMATRIX *pubmat);
int RCPTINFO_match_privkey(const RCPTINFO *rcptinfo, const PRIVKEY *privkey);
int matrix_is_match(const MATRIX *public_matrix, const MATRIX *private_matrix)
{
	int i;
	int ret = 0;

	const MATRIX *pubmat = public_matrix;
	const MATRIX *primat = private_matrix;
	
	int col = public_matrix->col;
	int row = public_matrix->row;
	
	

	EC_GROUP *ec_group = NULL;
	EC_KEY *ec_key = EC_KEY_new();
	BIGNUM *bn = BN_new();
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();
	EC_POINT *pt = NULL;

	unsigned char *pbn, *ppt;
	unsigned int bnlen, ptlen;
	unsigned char ptbuf[128];


	if (OBJ_obj2nid(pubmat->ecoid) != OBJ_obj2nid(primat->ecoid))
	{
		goto end;
	}		

	if (OBJ_obj2nid(pubmat->mapoid) != OBJ_obj2nid(primat->mapoid))
	{
		goto end;
	}

	if ((pubmat->col != primat->col) || (pubmat->row != primat->row))
	{
		goto end;
	}
	
	ec_group = EC_GROUP_new_by_curve_name(OBJ_obj2nid(pubmat->ecoid));
	EC_KEY_set_group(ec_key, ec_group);
	pt = EC_POINT_new(ec_group);	
	
	EC_GROUP_get_order(ec_group, order, ctx);
	bnlen = BN_num_bytes(order);
	ptlen = bnlen * 2;
	pbn = ASN1_STRING_data(primat->data);
	ppt = ASN1_STRING_data(pubmat->data) + 1;

	ptbuf[0] = 4;
	
	for (i=0; i<col*row; i++)
	{
		BN_bin2bn(pbn, bnlen, bn);
		pbn += bnlen;	
	
		memcpy(ptbuf + 1, ppt, ptlen);
		EC_POINT_oct2point(ec_group, pt, ptbuf, ptlen+1, ctx);
		ppt += ptlen;

		EC_KEY_set_private_key(ec_key, bn);
		EC_KEY_set_public_key(ec_key, pt);
		
		if (!EC_KEY_check_key(ec_key))
			goto end;
	}	
		
	ret = 1;	
end:	
	return ret;

}

int cert_pubmat_match(const PRIVKEY *cert, const MATRIX *pubmat)
{
	int ret = 0;
	
	EC_GROUP *ec_group = NULL;
	BIGNUM *bn = BN_new();
	EC_POINT *pt = NULL;
	EC_KEY *ec_key = EC_KEY_new();

	if (!ec_key || !bn || !cert || !pubmat)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!PUBMATRIX_is_valid(pubmat))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (cert->ver != pubmat->ver)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_cmp(cert->matrixid, pubmat->id))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (OBJ_obj2nid(cert->ecoid) != OBJ_obj2nid(pubmat->ecoid))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!ASN1_INTEGER_to_BN(cert->keydata, bn))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(pt = PUBMATRIX_get_ptkey(pubmat, ASN1_STRING_data(cert->keyid), ASN1_STRING_length(cert->keyid))))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(ec_group = EC_GROUP_new_by_curve_name(OBJ_obj2nid(cert->ecoid))))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	EC_KEY_set_group(ec_key, ec_group);
	EC_KEY_set_private_key(ec_key, bn);
	EC_KEY_set_public_key(ec_key, pt);

	ret = EC_KEY_check_key(ec_key);

end:
	if (ec_group) EC_GROUP_free(ec_group);
	if (bn) BN_free(bn);
	if (pt) EC_POINT_free(pt);
	if (ec_key) EC_KEY_free(ec_key);

	return ret;	
}

int check_privkey_rcptinfo(const PRIVKEY *privkey, const RCPTINFO *rcptinfo)
{
	if (!privkey || !rcptinfo)
	{
		return 0;
	}

	if (ASN1_STRING_cmp(privkey->matrixid, rcptinfo->matrixid))
	{
		return 0;
	}

	if (ASN1_STRING_cmp(privkey->keyid, rcptinfo->rcptid))
	{
		return 0;
	}

	return 1;
}
// ----- MATCH FUNCTIONS END-----


// ----- SIGNER INFO FUNCTIONS BEGIN -----
const EVP_MD *SIGINFO_get_md(const SIGINFO *siginfo)
{
	OpenSSL_add_all_digests();
	return EVP_get_digestbynid(OBJ_obj2nid(siginfo->mdoid));
}
// ----- SIGNER INFO FUNCTIONS END -----


// ----- RECIPIENT INFO FUNCTIONS BEGIN -----
const EVP_MD *RCPTINFO_get_kdf_md(const RCPTINFO *rcptinfo)
{
	OpenSSL_add_all_digests();
	return EVP_get_digestbynid(OBJ_obj2nid(rcptinfo->kdfmd));
}

KDF RCPTINFO_get_kdf(const RCPTINFO *rcptinfo)
{
	return x9_63_kdf_md(RCPTINFO_get_kdf_md(rcptinfo));
}
const EVP_CIPHER *RCPTINFO_get_cipher(const RCPTINFO *rcptinfo)
{
	EVP_add_cipher(EVP_aes_128_cbc());
	EVP_add_cipher(EVP_aes_192_cbc());
	EVP_add_cipher(EVP_aes_256_cbc());
	EVP_add_cipher(EVP_aes_128_ofb());
	return EVP_get_cipherbynid(OBJ_obj2nid(rcptinfo->encalg));
}

const EVP_MD *RCPTINFO_get_hmac_md(const RCPTINFO *rcptinfo)
{
	OpenSSL_add_all_digests();
	return EVP_get_digestbynid(OBJ_obj2nid(rcptinfo->macalg));
}

EC_POINT *RCPTINFO_get_ecpoint(const RCPTINFO *rcptinfo, const EC_GROUP *ec_group)
{
	EC_POINT *pt = NULL;
	
	int ok = 0;
	BN_CTX *ctx = BN_CTX_new();
	unsigned char *ptdata = ASN1_STRING_data(rcptinfo->ecpoint);
	unsigned int ptlen = ASN1_STRING_length(rcptinfo->ecpoint);


	if (!rcptinfo || !ec_group ||!ctx)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(pt = EC_POINT_new(ec_group)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!EC_POINT_oct2point(ec_group, pt, ptdata, ptlen, ctx))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	ok = 1;

end:
	if (!ok && pt)
	{
		EC_POINT_free(pt);
		pt = NULL;
	}

	if (ctx) BN_CTX_free(ctx);

	return pt;
}

// ----- RECIPIENT INFO FUNCTIONS END -----


// ----- ASN1 PRINT FUNCTIONS BEGIN -----------------------------------------
int MATRIX_print(const MATRIX *matrix, FILE *outfp, int flag)
{
	int ret = 0;

	EC_GROUP *ec_group = NULL;
	unsigned char *matrixid = NULL;
	unsigned int matrixidlen;
	int bnlen;
	int is_primat = 0; // TOFIX: get the value from flag

	if (!MATRIX_is_valid(matrix, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	matrixidlen = ASN1_STRING_length(matrix->id);	
	if (!(matrixid = (char *)OPENSSL_malloc(matrixidlen + 1)))
	{
		goto end;
	}
	memcpy(matrixid, ASN1_STRING_data(matrix->id), matrixidlen);
	matrixid[matrixidlen] = 0;

	if (!(ec_group = MATRIX_get_ecgroup(matrix)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if ((bnlen = EC_GROUP_get_bn_bytes(ec_group)) <= 0)
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}	

	// version:matrixid:ecname:col:row:mapname:
	fprintf(outfp, 
		"Version         : %d\n"
		"MatrixID        : %s\n"
		"EllipticCurve   : %s\n"
		"ColumnSize      : %d\n"
		"RowSize         : %d\n"
		"MapAlgorithm    : %s\n", 
		matrix->ver, 
		matrixid, 
		OBJ_nid2sn(OBJ_obj2nid(matrix->ecoid)),	
		matrix->col, 
		matrix->row, 
		OBJ_nid2sn(OBJ_obj2nid(matrix->mapoid)));

	
	ret = 1;
	
end:
	if (ec_group) EC_GROUP_free(ec_group);
	if (matrixid) OPENSSL_free(matrixid);

	return ret;
}

int PRIVKEY_print(const PRIVKEY *privkey, FILE *outfp, int flag)
{
	int ret = 0;

	EC_KEY *ec_key = EC_KEY_new();
	BN_CTX *ctx = BN_CTX_new();
	char *matrixid = NULL;
	unsigned int matrixidlen;
	char *keyid = NULL;
	unsigned int keyidlen;


	matrixidlen = ASN1_STRING_length(privkey->matrixid);
	if (!(matrixid = (char *)OPENSSL_malloc(matrixidlen + 1)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	memcpy(matrixid, ASN1_STRING_data(privkey->matrixid), matrixidlen);
	matrixid[matrixidlen] = 0;

	keyidlen = ASN1_STRING_length(privkey->keyid);
	if (!(keyid = (char *)OPENSSL_malloc(keyidlen + 1)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	memcpy(keyid, ASN1_STRING_data(privkey->keyid), keyidlen);
	keyid[keyidlen] = 0;

	if (!(ec_key = PRIVKEY_get_eckey(privkey)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	
	// version:ecname:matrixid:keyid:key
	fprintf(outfp, 
		"Version          : %d\n"
		"EllipticCurve    : %s\n"
		"MatrixID         : %s\n"
		"UserIdentity     : %s\n"
		"PrivateKey       : %s\n"
		"PublicKey        : %s\n", 
		privkey->ver, 
		OBJ_nid2sn(OBJ_obj2nid(privkey->ecoid)),
		matrixid,
		keyid,
		flag ? BN_bn2hex(EC_KEY_get0_private_key(ec_key)) : "(secret)",
		EC_POINT_point2hex(EC_KEY_get0_group(ec_key), EC_KEY_get0_public_key(ec_key), 4, ctx));

	ret = 1;

end:
	if (matrixid) OPENSSL_free(matrixid);
	if (keyid) OPENSSL_free(keyid);
	if (ctx) BN_CTX_free(ctx);
	if (ec_key) EC_KEY_free(ec_key);

	return ret;	
}

int SIGINFO_print(const SIGINFO *siginfo, FILE *outfp, int flag)
{
	int ret = 0;

	char *matrixid = NULL;
	char *signerid = NULL;
	unsigned int matrixidlen, signeridlen;	

	matrixidlen = ASN1_STRING_length(siginfo->matrixid);
	if (!(matrixid = (char *)OPENSSL_malloc(matrixidlen + 1)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	memcpy(matrixid, ASN1_STRING_data(siginfo->matrixid), matrixidlen);
	matrixid[matrixidlen] = 0;

	signeridlen = ASN1_STRING_length(siginfo->signerid);
	if (!(signerid = (char *)OPENSSL_malloc(signeridlen + 1)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	memcpy(signerid, ASN1_STRING_data(siginfo->signerid), signeridlen);
	signerid[signeridlen] = 0;	


	// version:matrixid:signer:ecdsa-alg:[sig-value]
	fprintf(outfp, 
		"Version         : %d\n"
		"MatrixID        : %s\n"
		"SignerID        : %s\n"
		"SignatureType   : ECDSA-%s:\n",
		siginfo->ver,
		matrixid,
		signerid,
		OBJ_nid2sn(OBJ_obj2nid(siginfo->mdoid)));

	ret = 1;

end:
	if (matrixid) OPENSSL_free(matrixid);
	if (signerid) OPENSSL_free(signerid);

	return ret;
}

int RCPTINFO_print(const RCPTINFO *rcptinfo, FILE *outfp, int flag)
{
	int ret = 0;

	unsigned char *matrixid = NULL;
	unsigned char *rcptid = NULL;
	const EVP_MD *kdf_md;
	const EVP_CIPHER *cipher;
	const EVP_MD *mac_md;

	if (!RCPTINFO_is_valid(rcptinfo, NULL))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!(matrixid = ASN1_new_buffer_by_string(rcptinfo->matrixid)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!(rcptid = ASN1_new_buffer_by_string(rcptinfo->rcptid)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!(kdf_md = RCPTINFO_get_kdf_md(rcptinfo)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!(cipher = RCPTINFO_get_cipher(rcptinfo)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!(mac_md = RCPTINFO_get_hmac_md(rcptinfo)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	//1version:2matrixid:3rcptid:4kdfmd:5encalg:6macalg:7ecpoint:8:9
	fprintf(outfp, 
		"Version             : %d\n"
		"MatrixID            : %s\n"
		"RecipientID         : %s\n"
		"KDF-Algorithm       : X9.63-%s\n"
		"CipherAlgorithm     : %s\n"
		"MAC-Algorithm       : HMAC-%s\n",
		rcptinfo->ver,
		matrixid,
		rcptid,
		OBJ_nid2sn(EVP_MD_nid(kdf_md)),
		OBJ_nid2sn(EVP_CIPHER_nid(cipher)),
		OBJ_nid2sn(EVP_MD_nid(mac_md)));

	ret = 1;

end:
	if (matrixid) OPENSSL_free(matrixid);
	if (rcptid) OPENSSL_free(rcptid);

	return ret;
}
// 	----- ASN1 PRINT FUNCTIONS END -----------------------------------------

// ----- ASN1 IS_VALID FUNCTIONS BEGIN -----------------------------------------
int MATRIX_is_valid(const MATRIX *matrix, int private)
{
	int ret = 0;

	EC_GROUP *ec_group = NULL;
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();
	int bnlen, datalen;
	const EVP_MD *md;

	assert(matrix);	

	if (!matrix || !order || !ctx)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}

	if (matrix->ver != CPK_VERSION)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}

	if (!MATRIX_get_map_md(matrix))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}

	if (!(ec_group = MATRIX_get_ecgroup(matrix)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}

	EC_GROUP_get_order(ec_group, order, ctx);
	bnlen = BN_num_bytes(order);

	if (private)
		datalen = bnlen * matrix->col * matrix->row;
	else
		datalen = bnlen * 2 * matrix->col * matrix->row + 1;


	if (ASN1_STRING_length(matrix->data) != datalen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}

	if (!private && ASN1_STRING_data(matrix->data)[0] != EC_POINT_FORMAT)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);	
		goto end;
	}

	ret = 1;

end:
	if (ec_group) EC_GROUP_free(ec_group);
	if (order) BN_free(order);
	if (ctx) BN_CTX_free(ctx);

	return ret;
}

int PRIVKEY_is_valid(const PRIVKEY *privkey)
{
	int ret = 0;
	EC_GROUP *ec_group = NULL;

	assert(privkey);

	if (privkey->ver != CPK_VERSION)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(ec_group = PRIVKEY_get_ecgroup(privkey)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_length(privkey->matrixid) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	
	if (ASN1_STRING_length(privkey->keyid) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_length(privkey->keydata) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;

end:
	EC_GROUP_free(ec_group);
	
	return ret;	
}

int SIGINFO_is_valid(const SIGINFO *siginfo)
{
	return 1;
}

int RCPTINFO_is_valid(const RCPTINFO *rcptinfo, const EC_GROUP *ec_group)
{
	int ret = 0;
	EC_POINT *pt = NULL;

	assert(rcptinfo);

	if (rcptinfo->ver != CPK_VERSION)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_length(rcptinfo->matrixid) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_length(rcptinfo->rcptid) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!RCPTINFO_get_kdf_md(rcptinfo))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!RCPTINFO_get_cipher(rcptinfo))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!RCPTINFO_get_hmac_md(rcptinfo))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!ec_group)
	{
		;
	}
	else if (!(pt = RCPTINFO_get_ecpoint(rcptinfo, ec_group)))		
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_length(rcptinfo->enceddata) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;

end:
	if (pt) EC_POINT_free(pt);

	return ret;	

}

// ----- SIGN/VERIFY ENCRYPT/DECRYPT BEGIN -----
SIGINFO *PRIVKEY_sign(const PRIVKEY *privkey, const EVP_MD *md, 
		      const unsigned char *dgst, unsigned int dgstlen)
{
	SIGINFO *siginfo = SIGINFO_new();

	int ok = 0;
	EC_KEY *ec_key = NULL;
	ECDSA_SIG *ecdsa_sig = NULL;
	unsigned char sig[256];
	unsigned int siglen;
	unsigned char *psig;
	unsigned char *matrixid;
	unsigned int matrixidlen; 
	unsigned char *keyid;
	unsigned int keyidlen;

	if (!siginfo || !privkey || !md || !dgst)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}			

	if (dgstlen != EVP_MD_size(md))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	matrixid = ASN1_STRING_data(privkey->matrixid);
	matrixidlen = ASN1_STRING_length(privkey->matrixid);
	keyid = ASN1_STRING_data(privkey->keyid);
	keyidlen = ASN1_STRING_length(privkey->keyid);
	
	// do sign	
	if (!(ec_key = PRIVKEY_get_eckey(privkey)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!(ecdsa_sig = ECDSA_do_sign(dgst, dgstlen, ec_key)))
	{
		fprintf(stderr, "%s ", ERR_reason_error_string(ERR_get_error()));
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	psig = sig;
	siglen = i2d_ECDSA_SIG(ecdsa_sig, &psig);
	

	// set siginfo
	siginfo->ver = CPK_VERSION;
	ASN1_STRING_set(siginfo->matrixid, matrixid, matrixidlen);
	ASN1_STRING_set(siginfo->signerid, keyid, keyidlen);
	ASN1_OBJECT_free(siginfo->mdoid);
	siginfo->mdoid = OBJ_nid2obj(EVP_MD_nid(md));
	ASN1_STRING_set(siginfo->sigvalue, sig, siglen);
		
	ok = 1;

end:
	if (!ok && siginfo)
	{
		SIGINFO_free(siginfo);
		siginfo = NULL;
	}

 	if (ec_key) EC_KEY_free(ec_key);
	if (ecdsa_sig) ECDSA_SIG_free(ecdsa_sig);

	return siginfo;
}

int PUBMATRIX_verify(const PUBMATRIX *pubmat, const unsigned char *dgst, 
		unsigned int dgstlen, const SIGINFO *siginfo)
{
	int ret = 0;
	
	EC_KEY *ec_key = NULL;
	ECDSA_SIG *ecdsa_sig = NULL;
	const EVP_MD *md;
	unsigned char *signerid;
	unsigned int signeridlen;
	const unsigned char *p;
	unsigned char *sig;
	unsigned int siglen;	

	if (!pubmat || !dgst || !siginfo)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (ASN1_STRING_cmp(pubmat->id, siginfo->matrixid))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	signerid = ASN1_STRING_data(siginfo->signerid);
	signeridlen = ASN1_STRING_length(siginfo->signerid);

	if (!(md = EVP_get_digestbynid(OBJ_obj2nid(siginfo->mdoid))))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
		
	if (md != EVP_sha1())
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (EVP_MD_size(md) != dgstlen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(ec_key = PUBMATRIX_get_eckey(pubmat, signerid, signeridlen))) 
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	


	sig = ASN1_STRING_data(siginfo->sigvalue);
	siglen = ASN1_STRING_length(siginfo->sigvalue);
	p = sig;	
	if (!(ecdsa_sig = d2i_ECDSA_SIG(NULL, &p, siglen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	ret = ECDSA_do_verify(dgst, dgstlen, ecdsa_sig, ec_key);

end:
	if (ec_key) EC_KEY_free(ec_key);
	if (ecdsa_sig) ECDSA_SIG_free(ecdsa_sig);

	return ret;	
}





RCPTINFO *PUBMATRIX_encrypt(const MATRIX *public_matrix,
			const char *rcptid, unsigned int rcptidlen,
			const EVP_MD *kdf_md, const EVP_CIPHER *cipher, const EVP_MD *hmac_md,
			const unsigned char *data, size_t datalen)
{
	RCPTINFO *rcptinfo = RCPTINFO_new();
	
	int ok = 0;
	EC_GROUP *ec_group = NULL;
	EC_POINT *rcpt_pubkey = NULL;
	EC_KEY *tmp_eckey = EC_KEY_new();
	BN_CTX *bnctx = BN_CTX_new();
	unsigned char keyivmac[128];
	unsigned int keyivmaclen;
	unsigned char *enckey, *enciv, *hmackey;
	int enckeylen, encivlen, hmackeylen;
	unsigned char ecpoint[160];
	size_t ecpointlen = 160;
	unsigned char *enceddata = NULL;
	size_t enceddatalen;
	unsigned char macdata[HMAC_MAX_MD_CBLOCK];
	unsigned int macdatalen;

	KDF kdf;
	EVP_CIPHER_CTX cipher_ctx;
	HMAC_CTX hmac_ctx;
	unsigned char *p;
	int len;

	assert(public_matrix);
	assert(rcptid);
	assert(rcptidlen > 0);
	assert(kdf_md);
	assert(cipher);
	assert(hmac_md);
	assert(data);

	EVP_CIPHER_CTX_init(&cipher_ctx);
	HMAC_CTX_init(&hmac_ctx);

	// check input parameters
	if (!rcptinfo || !tmp_eckey || !bnctx)
	{ 
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	// prepare ecdh
	enckeylen = EVP_CIPHER_key_length(cipher);
	encivlen = EVP_CIPHER_block_size(cipher);
	hmackeylen = EVP_MD_size(hmac_md);
	keyivmaclen = enckeylen + encivlen + hmackeylen;

	if (!(rcpt_pubkey = PUBMATRIX_get_ptkey(public_matrix, rcptid, rcptidlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!(ec_group = PUBMATRIX_get_ecgroup(public_matrix))) 
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!EC_KEY_set_group(tmp_eckey, ec_group))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!EC_KEY_generate_key(tmp_eckey))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	
	
	if ((ecpointlen = EC_POINT_point2oct(ec_group, EC_KEY_get0_public_key(tmp_eckey), 
		4, ecpoint, ecpointlen, bnctx)) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(kdf = x9_63_kdf_md(kdf_md)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	

	// do ecdh
	if (!ECDH_compute_key(keyivmac, keyivmaclen, rcpt_pubkey, tmp_eckey, kdf))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	enckey = keyivmac;
	enciv = keyivmac + enckeylen;
	hmackey = keyivmac + enckeylen + encivlen;

	// do encrypt	
	if (!(enceddata = (unsigned char *)OPENSSL_malloc(datalen + EVP_MAX_BLOCK_LENGTH)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!EVP_EncryptInit(&cipher_ctx, cipher, enckey, enciv))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	p = enceddata;
	if (!EVP_EncryptUpdate(&cipher_ctx, p, &len, data, datalen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p += len;
	if (!EVP_EncryptFinal(&cipher_ctx, p, &len))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	p += len;
	enceddatalen = p - enceddata;	

	// compute HMAC of plaintext	
	HMAC_Init_ex(&hmac_ctx, hmackey, hmackeylen, hmac_md, NULL);	
	HMAC_Update(&hmac_ctx, data, datalen);
	HMAC_Final(&hmac_ctx, macdata, &macdatalen);

	// output RecipientInfo 
	//1 ver
	rcptinfo->ver = 1;
	//2 matrixid
	ASN1_STRING_set(rcptinfo->matrixid, ASN1_STRING_data(public_matrix->id), 
		ASN1_STRING_length(public_matrix->id));
	//3 rcptid
	ASN1_STRING_set(rcptinfo->rcptid, rcptid, rcptidlen);
	//4 kdfmd
	ASN1_OBJECT_free(rcptinfo->kdfmd);
	rcptinfo->kdfmd = OBJ_nid2obj(EVP_MD_nid(kdf_md));
	//5 cipher
	ASN1_OBJECT_free(rcptinfo->encalg);
	rcptinfo->encalg = OBJ_nid2obj(EVP_CIPHER_nid(cipher));
	//6 hmacalg
	ASN1_OBJECT_free(rcptinfo->macalg);
	rcptinfo->macalg = OBJ_nid2obj(EVP_MD_nid(hmac_md));
	//7 ecpoint
	ASN1_STRING_set(rcptinfo->ecpoint, ecpoint, ecpointlen);
	//8 enceddata
	ASN1_STRING_set(rcptinfo->enceddata, enceddata, enceddatalen);
	//9 macdata
	ASN1_STRING_set(rcptinfo->macdata, macdata, macdatalen);
			
	ok = 1;

	
end:
	if (!ok && rcptinfo)
	{
		RCPTINFO_free(rcptinfo);
		rcptinfo = NULL;
	}

	if (ec_group) EC_GROUP_free(ec_group);
	if (rcpt_pubkey) EC_POINT_free(rcpt_pubkey);
	if (tmp_eckey) EC_KEY_free(tmp_eckey);
	if (enceddata) OPENSSL_free(enceddata);
	EVP_CIPHER_CTX_cleanup(&cipher_ctx);
	HMAC_CTX_cleanup(&hmac_ctx);

	return rcptinfo;
}




int PRIVKEY_decrypt(const PRIVKEY *privkey, const RCPTINFO *rcptinfo, 
		  unsigned char *out, size_t *outlen)
{
	int ret = 0;

	EC_GROUP *ec_group = NULL;
	EC_POINT *tmp_pubkey = NULL;
	EC_KEY *rcpt_privkey = NULL;
	BN_CTX *bnctx = BN_CTX_new();
	const EVP_CIPHER *cipher;
	const EVP_MD *hmac_md;
	KDF kdf;

	unsigned char keyivmac[512];
	unsigned char *enckey, *enciv, *hmackey;
	int enckeylen, encivlen, hmackeylen, keyivmaclen;
	unsigned char *enceddata;
	unsigned int enceddatalen;
	unsigned char macdata[HMAC_MAX_MD_CBLOCK];
	unsigned int macdatalen;
	unsigned char *p;
	int len;

	EVP_CIPHER_CTX cipher_ctx;
	HMAC_CTX hmac_ctx;

	assert(privkey);
	assert(rcptinfo);
	assert(outlen);
	
	EVP_CIPHER_CTX_init(&cipher_ctx);
	HMAC_CTX_init(&hmac_ctx);

	
	
	// check input parameters
	if (!PRIVKEY_is_valid(privkey))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 

	if (!out)
	{
		*outlen = ASN1_STRING_length(rcptinfo->enceddata);
		ret = 1;
		goto end;
	}		

	if (!(ec_group = PRIVKEY_get_ecgroup(privkey)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 

	if (!RCPTINFO_is_valid(rcptinfo, ec_group))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}


	// do ecdh 
	if (!(rcpt_privkey = PRIVKEY_get_eckey(privkey)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 

	if (!(tmp_pubkey = RCPTINFO_get_ecpoint(rcptinfo, ec_group)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 

	if (!(cipher = RCPTINFO_get_cipher(rcptinfo)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 

	if (!(hmac_md = RCPTINFO_get_hmac_md(rcptinfo)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 
	
	if (!(kdf = RCPTINFO_get_kdf(rcptinfo)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 

	enckeylen = EVP_CIPHER_key_length(cipher);
	encivlen = EVP_CIPHER_block_size(cipher);
	hmackeylen = EVP_MD_size(hmac_md);	
	keyivmaclen = enckeylen + encivlen + hmackeylen;
	
	if (!ECDH_compute_key(keyivmac, keyivmaclen, tmp_pubkey, rcpt_privkey, kdf))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	// do decrypt
	enckey = keyivmac;
	enciv = keyivmac + enckeylen;
	hmackey = keyivmac + enckeylen + encivlen;

	enceddata = ASN1_STRING_data(rcptinfo->enceddata);
	enceddatalen = ASN1_STRING_length(rcptinfo->enceddata);

	if (!EVP_DecryptInit(&cipher_ctx, cipher, enckey, enciv))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	p = out;
	//fprintf(stderr, "shit %d\n", enceddatalen);
	if (!EVP_DecryptUpdate(&cipher_ctx, p, &len, enceddata, enceddatalen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p += len;
	len = 0;
	//fprintf(stderr, "shit %d\n", cipher_ctx.cipher->block_size);
	//fprintf(stderr, "shit %c\n", cipher_ctx.final[15]);
	if (!EVP_DecryptFinal(&cipher_ctx, p, &len))
	{
		const char *evpfile;
		int evpline;
		fprintf(stderr, "[%d] len = %d\n", __LINE__, len);
		ERR_get_error_line(&evpfile, &evpline);
		fprintf(stderr, "lib %s(%d)\n", evpfile, evpline);
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	p += len;
	*outlen = p - out;

	// verify HMAC
	HMAC_Init_ex(&hmac_ctx, hmackey, hmackeylen, hmac_md, NULL);	
	HMAC_Update(&hmac_ctx, out, *outlen);
	HMAC_Final(&hmac_ctx, macdata, &macdatalen);

	if (macdatalen != ASN1_STRING_length(rcptinfo->macdata))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (memcmp(macdata, ASN1_STRING_data(rcptinfo->macdata), macdatalen) != 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;

end:

	if (ec_group) EC_GROUP_free(ec_group);
	if (tmp_pubkey) EC_POINT_free(tmp_pubkey);
	if (rcpt_privkey) EC_KEY_free(rcpt_privkey);
	EVP_CIPHER_CTX_cleanup(&cipher_ctx);
	HMAC_CTX_cleanup(&hmac_ctx);

	return ret;	
}
// ----- SIGN/VERIFY ENCRYPT/DECRYPT BEGIN -----

// ----- ASN.1 I2F, F2I, I2FP, FP2I FUNCTIONS BEGIN -----
int i2fp_MATRIX(MATRIX *matrix, FILE *fp)
{
	assert(0);
	return 0;
}

int i2fp_PRIVKEY(PRIVKEY *privkey, FILE *fp)
{
	int ret = 0;
	int len;
	unsigned char *buf = NULL;
	unsigned char *p;

	if (!privkey || !fp)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if ((len = i2d_PRIVKEY(privkey, NULL)) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	
	
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	i2d_PRIVKEY(privkey, &p);	

	if (fwrite(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret =1;
end:
	if (buf) OPENSSL_free(buf);

	return ret;
	return 0;
}

int i2fp_SIGINFO(SIGINFO *siginfo, FILE *fp)
{
	int ret = 0;
	int len;
	unsigned char *buf = NULL;
	unsigned char *p;

	if (!siginfo || !fp)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if ((len = i2d_SIGINFO(siginfo, NULL)) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	i2d_SIGINFO(siginfo, &p);	

	if (fwrite(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret =1;
end:
	if (buf) OPENSSL_free(buf);

	return ret;
}

int i2fp_RCPTINFO(RCPTINFO *rcptinfo, FILE *fp)
{	
	int ret = 0;
	int len;
	unsigned char *buf = NULL;
	unsigned char *p;

	if (!rcptinfo || !fp)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if ((len = i2d_RCPTINFO(rcptinfo, NULL)) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	
	
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	i2d_RCPTINFO(rcptinfo, &p);	

	if (fwrite(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret =1;
end:
	if (buf) OPENSSL_free(buf);

	return ret;
}

int i2f_MATRIX(MATRIX *matrix, const char *file)
{
	assert(0);
	return 0;
}

int i2f_PRIVKEY(PRIVKEY *privkey, const char *file)
{
	assert(0);
	return 0;
}

int i2f_SIGINFO(SIGINFO *siginfo, const char *filename)
{
	int ret = 0;
	FILE *fp = NULL;
	int len;
	unsigned char *buf = NULL;
	unsigned char *p;

	if (!siginfo || !filename)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(fp = fopen(filename, "wb")))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if ((len = i2d_SIGINFO(siginfo, NULL)) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	
	
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	i2d_SIGINFO(siginfo, &p);	

	if (fwrite(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret =1;
end:
	if (fp) fclose(fp);
	if (buf) OPENSSL_free(buf);

	return ret;
}

int i2f_RCPTINFO(RCPTINFO *rcptinfo, const char *file)
{
	assert(0);
	return 0;
}

MATRIX *fp2i_MATRIX(FILE *fp)
{
	MATRIX *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;


	if (!(buf = ASN1_new_buffer_by_fp(fp, &len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	p = buf;
	if (!(ret = d2i_MATRIX(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		MATRIX_free(ret);
		ret = NULL;
	}
	if (buf) OPENSSL_free(buf);
		
	return ret;
}

PRIVKEY *fp2i_PRIVKEY(FILE *fp)
{
	PRIVKEY *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;


	if (!(buf = ASN1_new_buffer_by_fp(fp, &len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
		
	p = buf;
	if (!(ret = d2i_PRIVKEY(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		PRIVKEY_free(ret);
		ret = NULL;
	}

	if (buf) OPENSSL_free(buf);
	
	return ret;
}

SIGINFO *fp2i_SIGINFO(FILE *fp)
{
	SIGINFO *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;

	
	if (!(buf = ASN1_new_buffer_by_fp(fp, &len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	p = buf;
	if (!(ret = d2i_SIGINFO(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		SIGINFO_free(ret);
		ret = NULL;
	}
	if (buf) OPENSSL_free(buf);
	
	return ret;
}


RCPTINFO *fp2i_RCPTINFO(FILE *fp)
{
	RCPTINFO *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;

	if (!(buf = ASN1_new_buffer_by_fp(fp, &len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	if (!(ret = d2i_RCPTINFO(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		RCPTINFO_free(ret);
		ret = NULL;
	}

	if (buf) OPENSSL_free(buf);
	
	return ret;
}



MATRIX *f2i_MATRIX(const char *filename)
{
	MATRIX *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;
	FILE *fp = NULL;

	if (!(fp = fopen(filename, "rb")))
	{
		fprintf(stderr, "fopen( %s ) failed:", filename);
		goto end;
	}

	if ((len = filesize(filename)) <= 0)
	{
		fprintf(stderr, "filesize( %s ) error:", filename);
		goto end;
	}
		
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	
	if (fread(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	if (!(ret = d2i_MATRIX(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		MATRIX_free(ret);
		ret = NULL;
	}

	if (buf) OPENSSL_free(buf);
	if (fp) fclose(fp);
	
	return ret;
}

PRIVKEY *f2i_PRIVKEY(const char *filename)
{
	PRIVKEY *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;
	FILE *fp = NULL;

	if (!(fp = fopen(filename, "rb")))
	{
		fprintf(stderr, "fopen( %s ) failed:", filename);
		goto end;
	}

	if ((len = filesize(filename)) <= 0)
	{
		fprintf(stderr, "filesize( %s ) error:", filename);
		goto end;
	}
		
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	
	if (fread(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	if (!(ret = d2i_PRIVKEY(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		PRIVKEY_free(ret);
		ret = NULL;
	}

	if (buf) OPENSSL_free(buf);
	if (fp) fclose(fp);
	
	return ret;
}

SIGINFO *f2i_SIGINFO(const char *filename)
{
	SIGINFO *ret = NULL;

	int ok = 0;
	unsigned char *buf = NULL;
	unsigned int len;
	const unsigned char *p;
	FILE *fp = NULL;

	if (!(fp = fopen(filename, "rb")))
	{
		fprintf(stderr, "fopen( %s ) failed:", filename);
		goto end;
	}

	if ((len = filesize(filename)) <= 0)
	{
		fprintf(stderr, "filesize( %s ) error:", filename);
		goto end;
	}
		
	if (!(buf = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	
	if (fread(buf, 1, len, fp) != len)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	if (!(ret = d2i_SIGINFO(NULL, &p, len)))
	{
		fprintf(stderr, "%s(%d) decode error:", __FILE__, __LINE__);
		goto end;	
	}

	ok = 1;

end:
	if (!ok && ret)
	{
		SIGINFO_free(ret);
		ret = NULL;
	}

	if (buf) OPENSSL_free(buf);
	if (fp) fclose(fp);
	
	return ret;
}


RCPTINFO *f2i_RCPTINFO(const char *file)
{
	return 0;
}
// ----- F2I FUNCIONTS END -----



// ----- CPK BEGIN ------------------------------------------------------------
// ----- CPK STATIC FUNCTIONS DECLARE BEGIN -----------------------------------
PRIVKEY *CPK_read_keyfp(FILE *keyfp, const char *pass, int flag);
PRIVKEY *CPK_read_keyfile(const char *keyfile, const char *pass, int flag);
int CPK_write_keyfp(PRIVKEY *privkey, FILE *keyfp, const char *pass, int flag);
int CPK_write_keyfile(PRIVKEY *privkey, const char *keyfile, 
		const char *pass, int flag);
//
MATRIX *CPK_read_matfp(FILE *matfp, int flag);
MATRIX *CPK_read_matfile(const char *matfile, int flag);
//
SIGINFO *CPK_read_sigfp(FILE *sigfp, int flag);
SIGINFO *CPK_read_sigfile(const char *sigfile, int flag);
int CPK_write_sigfp(SIGINFO *siginfo, FILE *sigfp, int flag);
int CPK_write_sigfile(SIGINFO *siginfo, const char *sigfile, int flag);
//
RCPTINFO *CPK_read_encfp(FILE *encfp, int flag);
RCPTINFO *CPK_read_encfile(const char *encfile, int flag);
int CPK_write_encfp(RCPTINFO *rcptinfo, FILE *encfp, int flag);
int CPK_write_encfile(RCPTINFO *rcptinfo, const char *encfile, int flag);
// ----- CPK STATIC FUNCTIONS DECLARE END -------------------------------------

// ----- CPK API DECLARE BEGIN ------------------------------------------------
// -CPK PARSE FUNCTIONS -------------------------------------------------------
int CPK_print_privkey(PRIVKEY *privkey, FILE *outfp, int flag);
int CPK_print_matrix(MATRIX *matrix, FILE *outfp, int flag);
int CPK_print_siginfo(SIGINFO *siginfo, FILE *outfp, int flag);
int CPK_print_rcptinfo(RCPTINFO *rcptinfo, FILE *outfp, int flag);
//
int CPK_parse_keyfp(FILE *infp, const char *pass, FILE *outfp, int flag);
int CPK_parse_matfp(FILE *infp, FILE *outfp, int flag);
int CPK_parse_sigfp(FILE *infp, FILE *outfp, int flag);
int CPK_parse_encfp(FILE *infp, FILE *outfp, int flag);
//
int CPK_parse_keyfile(const char *infile, const char *pass, 
		const char *outfile, int flag);
int CPK_parse_matfile(const char *infile, const char *outfile, int flag);
int CPK_parse_sigfile(const char *infile, const char *outfile, int flag);
int CPK_parse_encfile(const char *infile, const char *outfile, int flag);
//
// -CPK GEN FUNCTIONS ---------------------------------------------------------
int CPK_gen_primatfp(const char *ec, int col, int row, const char *map,
		int flag);
int CPK_gen_primatfile(const char *ec, int col, int row, const char *map,
		const char *outfile, int flag);
int CPK_gen_pubmatfp(FILE *infp, FILE *outfp, int flag);
int CPK_gen_pubmatfile(const char *infile, const char *outfile, int flag);
int CPK_gen_keyfp(FILE *matfp, const char *id, FILE *keyfp, int flag);
int CPK_gen_keyfile(const char *matfile, const char *id, const char *keyfile,
		int flag);
//
// -CPK SIGN/ENC FUNCTIONS ----------------------------------------------------
int CPK_key_sign(const char *keyfile, const char *pass, const char *signalgo,
		const char *infile, const char *outfile, int flag);
int CPK_detachverify(const char *matfile, const char *signedfile, 
		const char *sigfile, int flag);
int CPK_verify(const char *matfile, const char *infile, int flag);
int CPK_detachencrypt(const char *matfile, const char *keyid, 
		const char *kdf, const char *encalg, const char *macalg,
		const char *infile, const char *outfile, int flag);
int CPK_encrypt(const char *matfile, const char *rcptid, const char *infile, 
		const char *outfile, int flag);
//
int CPK_id2pubkey_fp(FILE *infp, const char *id, FILE *outfp);
int CPK_id2pubkey_file(const char *infile, const char *id, const char *outfile);
//
// - CPK UTIL FUNCTIONS --------------------------------------------------------
void CPK_add_all_ciphers(void);
int CPK_ecname_is_valid(const char *ecname);
const EVP_MD *CPK_signalgo_is_valid(const char *name);
const EVP_MD *CPK_mapalgo_is_valid(const char *name);
//
// ----- CPK API DECLARE END ---------------------------------------------------


// - CPK UTIL FUNCTIONS IMPLEMENTATION BEGIN -----------------------------------
void CPK_add_all_ciphers(void)
{
	EVP_add_cipher(EVP_aes_128_cbc());
	EVP_add_cipher(EVP_aes_192_cbc());
	EVP_add_cipher(EVP_aes_256_cbc());
	EVP_add_cipher(EVP_aes_128_ofb());
	EVP_add_cipher(EVP_aes_192_ofb());
	EVP_add_cipher(EVP_aes_256_ofb());
}

int CPK_ecname_is_valid(const char *ecname)
{
	return 1;
}

const EVP_MD *CPK_signalgo_is_valid(const char *signalgo)
{
	if 	(strcmp(signalgo, "SHA1") == 0)
		return EVP_sha1();
	else if (strcmp(signalgo, "ECDSA-SHA1") == 0)
		return EVP_sha1();
	else 
		return NULL;
}


// BEGIN ALGORITHM

// END ALGORITHM


const EVP_MD *CPK_mapalgo_is_valid(const char *name)
{
	if 	(strcmp(name, "MAP-SHA1") == 0)
		return EVP_sha1();
	else if	(strcmp(name, "SHA1") == 0)
		return EVP_sha1();

	else if (strcmp(name, "MAP-SHA256") == 0)
		return EVP_sha256();
	else if (strcmp(name, "SHA256") == 0)
		return EVP_sha256();

	else if (strcmp(name, "MAP-SHA384") == 0)
		return EVP_sha384();
	else if (strcmp(name, "SHA384") == 0)
		return EVP_sha384();
	
	else if (strcmp(name, "MAP-SHA512") == 0)
		return EVP_sha512();
	else if (strcmp(name, "SHA512") == 0)
		return EVP_sha512();
	else 
		return NULL;
}

// - CPK UTIL FUNCTIONS IMPLEMENTATION END -------------------------------------

// ----- CPK STATIC FUNCTIONS IMPLEMENTATION BEGIN -----------------------------
PRIVKEY *CPK_read_keyfp(FILE *keyfp, const char *pass, int flag)
{
	assert(keyfp);
	//assert(pass);

	return fp2i_PRIVKEY(keyfp);
}

PRIVKEY *CPK_read_keyfile(const char *keyfile, const char *pass, int flag)
{
	PRIVKEY *privkey = NULL;
	FILE *keyfp = NULL;

	if (!keyfile)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return NULL;
	}

	if (!(keyfp = fopen(keyfile, "rb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, keyfile, __FILE__, __LINE__);
		return NULL;
	}
	
	if (!(privkey =  CPK_read_keyfp(keyfp, pass, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE":", __FILE__, __LINE__);
	}

	fclose(keyfp);
	return privkey;
}	

int CPK_write_keyfp(PRIVKEY *privkey, FILE *keyfp, const char *pass, int flag)
{
	if (!privkey || !keyfp)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return 0;
	}

	return i2fp_PRIVKEY(privkey, keyfp);
}

int CPK_write_keyfile(PRIVKEY *privkey, const char *keyfile, const char *pass,
		int flag)
{
	int ret = 0;
	FILE *keyfp = NULL;

	if (!privkey || !keyfile)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return 0;
	}

	if (!(keyfp = fopen(keyfile, "wb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, keyfile, __FILE__, __LINE__);
		return 0; 
	}

	if (!(ret = CPK_write_keyfp(privkey, keyfp, pass, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
	}
	
	fclose(keyfp);
	return ret;	
}

MATRIX *CPK_read_matfp(FILE *matfp, int flag)
{
	return fp2i_MATRIX(matfp);
}

MATRIX *CPK_read_matfile(const char *matfile, int flag)
{
	MATRIX *matrix = NULL;
	FILE *matfp = NULL;

	if (!matfile)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return NULL;
	}

	if (!(matfp = fopen(matfile, "rb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, matfile, __FILE__, __LINE__);
		return NULL;
	}
	
	if (!(matrix =  CPK_read_matfp(matfp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE":", __FILE__, __LINE__);
	}

	fclose(matfp);
	return matrix;
}	

SIGINFO *CPK_read_sigfp(FILE *sigfp, int flag)
{
	return fp2i_SIGINFO(sigfp);
}

SIGINFO *CPK_read_sigfile(const char *sigfile, int flag)
{
	SIGINFO *siginfo = NULL;
	FILE *sigfp = NULL;

	if (!sigfile)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return NULL;
	}

	if (!(sigfp = fopen(sigfile, "rb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, sigfile, __FILE__, __LINE__);
		return NULL;
	}
	
	if (!(siginfo =  CPK_read_sigfp(sigfp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE":", __FILE__, __LINE__);
	}

	fclose(sigfp);
	return siginfo;
}

int CPK_write_sigfp(SIGINFO *siginfo, FILE *sigfp, int flag)
{
	return i2fp_SIGINFO(siginfo, sigfp);
}


int CPK_write_sigfile(SIGINFO *siginfo, const char *sigfile, int flag)
{
	int ret = 0;
	FILE *sigfp = NULL;

	if (!sigfile)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return 0;
	}

	if (!(sigfp = fopen(sigfile, "wb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, sigfile, __FILE__, __LINE__);
		return 0;
	}

	if (!(ret = CPK_write_sigfp(siginfo, sigfp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE":", __FILE__, __LINE__);
	}
	
	fclose(sigfp);
	return ret;
}


RCPTINFO *CPK_read_encfp(FILE *encfp, int flag)
{
	return fp2i_RCPTINFO(encfp);
}

RCPTINFO *CPK_read_encfile(const char *encfile, int flag)
{
	RCPTINFO *rcptinfo = NULL;
	FILE *encfp = NULL;

	if (!encfile)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return NULL;
	}

	if (!(encfp = fopen(encfile, "rb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, encfile, __FILE__, __LINE__);
		return NULL;
	}
	
	if (!(rcptinfo =  CPK_read_encfp(encfp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE":", __FILE__, __LINE__);
	}

	fclose(encfp);
	return rcptinfo;
}

int CPK_write_encfp(RCPTINFO *rcptinfo, FILE *fp, int flag)
{
	return i2fp_RCPTINFO(rcptinfo, fp);
}

int CPK_write_encfile(RCPTINFO *rcptinfo, const char *file, int flag)
{
	
	int ret = 0;
	FILE *fp = NULL;

	if (!file)
	{
		fprintf(stderr, STR_ERROR_INVALPARAMS, __FILE__, __LINE__);
		return 0;
	}

	if (!(fp = fopen(file, "wb")))
	{
		fprintf(stderr, STR_ERROR_OPENFILE, file, __FILE__, __LINE__);
		return 0;
	}

	if (!(ret = CPK_write_encfp(rcptinfo, fp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE":", __FILE__, __LINE__);
	}
	
	fclose(fp);
	return ret;
}
// ----- CPK STATIC FUNCTIONS IMPLEMENTATION END -------------------------------



// -CPK PARSE FUNCTIONS IMPLEMENTATION BEGIN -----------------------------------
int CPK_parse_keyfp(FILE *infp, const char *pass, FILE *outfp, int flag)
{
	int ret = 0;
	PRIVKEY *privkey = NULL;

	if (!(privkey = CPK_read_keyfp(infp, pass, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!PRIVKEY_print(privkey, outfp, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (privkey) PRIVKEY_free(privkey);
	return ret;
}

int CPK_parse_matfp(FILE *infp, FILE *outfp, int flag)
{
	int ret = 0;
	MATRIX *matrix = NULL;

	assert(infp);
	assert(outfp);

	if (!(matrix = CPK_read_matfp(infp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	
	if (!MATRIX_print(matrix, outfp, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (matrix) MATRIX_free(matrix);
	return ret;
}

int CPK_parse_sigfp(FILE *infp, FILE *outfp, int flag)
{
	int ret = 0;
	SIGINFO *siginfo = NULL;

	assert(infp);
	assert(outfp);
	
	if (!(siginfo = CPK_read_sigfp(infp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!SIGINFO_print(siginfo, outfp, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (siginfo) SIGINFO_free(siginfo);
	return ret;
}

int CPK_parse_encfp(FILE *infp, FILE *outfp, int flag)
{
	int ret = 0;
	RCPTINFO *rcptinfo = NULL;

	assert(infp);
	assert(outfp);

	if (!infp || !outfp)
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!(rcptinfo = CPK_read_encfp(infp, flag)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	if (!RCPTINFO_print(rcptinfo, outfp, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (rcptinfo) RCPTINFO_free(rcptinfo);
	return ret;
}

// FIXME
int CPK_parse_keyfile(const char *infile, const char *pass, 
		const char *outfile, int flag)
{
	int ret = 0;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (!CPK_parse_keyfp(infp?infp:stdin, pass, outfp?outfp:stdout, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);	
	return ret;
}	
	

int CPK_parse_matfile(const char *infile, const char *outfile, int flag)
{
	int ret = 0;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (!CPK_parse_matfp(infp?infp:stdin, outfp?outfp:stdout, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);	
	return ret;
}	

int CPK_parse_sigfile(const char *infile, const char *outfile, int flag)
{
	int ret = 0;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (!CPK_parse_sigfp(infp?infp:stdin, outfp?outfp:stdout, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);	
	return ret;
}	

int CPK_parse_encfile(const char *infile, const char *outfile, int flag)
{
	int ret = 0;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (!CPK_parse_encfp(infp?infp:stdin, outfp?outfp:stdout, flag))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);	
	return ret;
}	
// -CPK PARSE FUNCTIONS IMPLEMENTATION END -------------------------------------

int CPK_gen_privmatrix(const char *ecname, int col, int row, const char *mdname, FILE *fp)
{
	int ret = 0;
	
	EC_GROUP *ec_group = NULL;
	const EVP_MD *md;
	PRIVMATRIX *primat = NULL;
	PUBMATRIX *pubmat = NULL;
	unsigned char *matrixid;
	unsigned int matrixidlen;
	unsigned char *buf = NULL;
	unsigned int buflen;
	unsigned char *p;


	//check input 
	if (!(ec_group = EC_GROUP_new_by_curve_name(OBJ_txt2nid(ecname))))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	OpenSSL_add_all_digests();
	if (!(md = EVP_get_digestbyname(mdname)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!colrowmap_is_valid(col, row, md))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	//generate
	if (!(primat = PRIVMATRIX_create(ec_group, col, row, md)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
		
	if (!(pubmat = PRIVMATRIX_gen_pubmat(primat)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	matrixid = ASN1_STRING_data(pubmat->id);  //FIXME
	matrixidlen = ASN1_STRING_length(pubmat->id);
	ASN1_STRING_set(primat->id, matrixid, matrixidlen); //FIXME

	//output
	buflen = i2d_MATRIX(primat, NULL);
	
	if (!(buf = (unsigned char *)OPENSSL_malloc(buflen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	p = buf;
	i2d_MATRIX(primat, &p);
	
	if (fwrite(buf, 1, buflen, fp) != buflen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:

	if (ec_group) EC_GROUP_free(ec_group);
	//if (primat) MATRIX_free(primat);  //FIXME
	//if (pubmat) MATRIX_free(pubmat);  //FIXME
	if (buf) OPENSSL_free(buf);

	return ret;
}

int CPK_gen_pubmatrix(FILE *infp, FILE *outfp)
{
	int ret = 0;

	unsigned char *inbuf = NULL;
	unsigned char *outbuf = NULL;
	unsigned int outbuflen;
	unsigned char *pout;

	PRIVMATRIX *primat = NULL;
	PUBMATRIX *pubmat = NULL;
	
		
	if (!(primat = (MATRIX *)CPK_read_matfp(infp, 1)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}


	if (!(pubmat = PRIVMATRIX_gen_pubmat(primat)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	outbuflen = i2d_MATRIX(pubmat, NULL);
	
	if (!(outbuf = (unsigned char *)OPENSSL_malloc(outbuflen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	pout = outbuf;
	i2d_MATRIX(pubmat, &pout);
	
	if (fwrite(outbuf, 1, outbuflen, outfp) != outbuflen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	ret = 1;

end:
	
	if (inbuf) OPENSSL_free(inbuf);
	if (outbuf) OPENSSL_free(outbuf);
	if (primat) MATRIX_free(primat);
	if (pubmat) MATRIX_free(pubmat);

	return ret;
}


int EC_GROUP_get_bn_bytes(const EC_GROUP *ec_group)
{
	//TOFIX
	int bnlen = -1;
	BIGNUM *order = BN_new();
	BN_CTX *ctx = BN_CTX_new();

	if (!EC_GROUP_get_order(ec_group, order, ctx))
	{
		BN_free(order);
		BN_CTX_free(ctx);
		return -1;
	}

	bnlen = BN_num_bytes(order);

	BN_free(order);
	BN_CTX_free(ctx);

	return bnlen;
}


int CPK_gen_privkey(FILE *infp, const char *keyid, FILE *fpout)
{
	int ret = 0;

	MATRIX *primat = NULL;
	PRIVKEY *privkey = NULL;
	unsigned char *inbuf = NULL;
	unsigned char *outbuf = NULL;
	unsigned int inbuflen, outbuflen;
	const unsigned char *pin;
	unsigned char *pout;

	if (!(inbuf = ASN1_new_buffer_by_fp(infp, &inbuflen)))	
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	pin = inbuf;
	if (!(primat = d2i_MATRIX(NULL, &pin, inbuflen)))	
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!(privkey = PRIVMATRIX_gen_privkey(primat, keyid, (unsigned int)strlen(keyid))))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	outbuflen = i2d_PRIVKEY(privkey, NULL);

	if (!(outbuf = (unsigned char *)OPENSSL_malloc(outbuflen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	pout = outbuf;
	i2d_PRIVKEY(privkey, &pout);

	if (fwrite(outbuf, 1, outbuflen, fpout) != outbuflen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;
end:
	if (primat) MATRIX_free(primat);
	if (privkey) PRIVKEY_free(privkey);
	if (inbuf) OPENSSL_free(inbuf);
	if (outbuf) OPENSSL_free(outbuf);
	
	return ret;
}

int CPK_key_sign(const char *keyfile, const char *pass, const char *signalgo,
		 const char *infile, const char *outfile, int flag)
{
	int ret = 0;

	PRIVKEY *privkey = NULL;
	SIGINFO *siginfo = NULL;
	const EVP_MD *md;
	unsigned char buf[4096];
	unsigned int buflen = 4096;
	unsigned char dgst[EVP_MAX_MD_SIZE];
	unsigned int dgstlen;
	EVP_MD_CTX ctx;
	size_t n;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	int detach = 0;
	int armor = 0;

	EVP_MD_CTX_init(&ctx);

	if (!(privkey = CPK_read_keyfile(keyfile, pass, flag)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	OpenSSL_add_all_digests();
	if (!(md = CPK_signalgo_is_valid(signalgo)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (md != EVP_sha1())
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, outfile, __FILE__, __LINE__);
			goto end;
		}
	}

	
	if (!EVP_DigestInit(&ctx, md))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	for (;;)
	{
                if (!(n = fread(buf, 1, buflen, infp?infp:stdin)))
                        break;

                if (!EVP_DigestUpdate(&ctx, buf, n))
		{
			fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
			goto end;
		}
	}

	if (!EVP_DigestFinal(&ctx, dgst, &dgstlen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
		
	if (!(siginfo = PRIVKEY_sign(privkey, md, dgst, dgstlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!CPK_write_sigfp(siginfo, outfp?outfp:stdout, flag))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;

end:
		
	if (privkey) PRIVKEY_free(privkey);
	if (siginfo) SIGINFO_free(siginfo);
	EVP_MD_CTX_cleanup(&ctx);

	return ret;	
}





char *ASN1_new_buffer_by_string(ASN1_STRING *asn1)
{
	int ok = 0;
	unsigned char *out = NULL;
	long len;

	if (!asn1)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (asn1->data == NULL || asn1->length <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	len = asn1->length + 1;
	
	if (!(out = (unsigned char *)OPENSSL_malloc(len)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	

	memcpy(out, asn1->data, asn1->length);
	out[asn1->length] = 0;


	ok = 1;
end:
	if (!ok && out)
	{
		OPENSSL_free(out);
		out = NULL;
	}
	
	return out;	
}

// signefile = NULL (default is stdin)
int CPK_detachverify(const char *matfile, const char *signedfile, 
		const char *sigfile, int flag)
{
	int ret = 0;

	MATRIX *matrix = NULL;
	FILE *signedfp = NULL;
	SIGINFO *siginfo = NULL;
	EVP_MD_CTX ctx;
	const EVP_MD *md;
	unsigned char buf[4096];
	unsigned int buflen = 4096;
	unsigned char dgst[EVP_MAX_MD_SIZE];
	unsigned int dgstlen;
	size_t n;

	EVP_MD_CTX_init(&ctx);
	
	if (!matfile)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(matrix = CPK_read_matfile(matfile, flag)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (signedfile)
	{
		if (!(signedfp = fopen(signedfile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, signedfile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (!(siginfo = CPK_read_sigfile(sigfile, flag)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!(md = SIGINFO_get_md(siginfo)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (md != EVP_sha1())
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!EVP_DigestInit(&ctx, md))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	for (;;)
	{
                if (!(n = fread(buf, 1, buflen, signedfp?signedfp:stdin)))
                        break;

                if (!EVP_DigestUpdate(&ctx, buf, n))
		{
			fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
			goto end;
		}
	}

	if (!EVP_DigestFinal(&ctx, dgst, &dgstlen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!PUBMATRIX_verify(matrix, dgst, dgstlen, siginfo))
	{
		fprintf(stderr, "verify failed:");
		goto end;
	}

	// TOFIX: output signer info
	
	ret = 1;

end:

	EVP_MD_CTX_cleanup(&ctx);
	if (siginfo) SIGINFO_free(siginfo);
	if (signedfp) fclose(signedfp);
	if (matrix) MATRIX_free(matrix);

	return ret;
}


int CPK_detachencrypt(const char *matfile, const char *keyid, 
		const char *kdf, const char *encalg, const char *macalg,
		const char *infile, const char *outfile, int flag)
{
	int ret = 0;

	MATRIX *matrix = NULL;
	RCPTINFO *rcptinfo = NULL;
	unsigned char *in = NULL;
	unsigned int inlen = ECIES_MAX_PLAINTEXT;
	const EVP_MD *kdfmd;
	const EVP_CIPHER *cipher;
	const EVP_MD *macmd;
	FILE *infp = NULL;
	FILE *outfp = NULL;
	size_t n;
	
	if (!keyid || strlen(keyid)<=0 || !kdf || !encalg || !macalg)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(matrix = CPK_read_matfile(matfile, flag)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, outfile, __FILE__, __LINE__);
			goto end;
		}
	}

	OpenSSL_add_all_digests();
	if (!(kdfmd = EVP_get_digestbyname(kdf)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	CPK_add_all_ciphers();
	if (!(cipher = EVP_get_cipherbyname(encalg)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(macmd = EVP_get_digestbyname(macalg)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}	

	if (!(in = (unsigned char *)OPENSSL_malloc(inlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(n = fread(in, 1, inlen, infp?infp:stdin)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (n == inlen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		fprintf(stderr, "input overflow (more than %d bytes):", inlen);
		goto end;
	}
	
	inlen = n;

	if (!(rcptinfo = PUBMATRIX_encrypt(matrix, keyid, strlen(keyid), 
		kdfmd, cipher, macmd, in, inlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!CPK_write_encfp(rcptinfo, outfp?outfp:stdout, flag))
	{	
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
		
	ret = 1;

end:
	if (matrix) MATRIX_free(matrix);
	if (rcptinfo) RCPTINFO_free(rcptinfo);
	if (in) OPENSSL_free(in);

	return ret;
}


unsigned char *ASN1_new_buffer_by_fp(FILE *fp, size_t *len)
{
	int ok = 0;
	unsigned char *out = NULL;
	unsigned char head[16];
	long n, headlen, bodylen, left;
	const unsigned char *p = head;
	int tag, class;

	if ((n = fread(head, 1, 16, fp)) <= 0)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!ASN1_get_object(&p, &bodylen, &tag, &class, n))
	{
		// ASN.1 decode error or 'header length' > headlen
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	headlen = p - head;

	if (!(out = (unsigned char *)OPENSSL_malloc(headlen + bodylen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	memcpy(out, head, n);
	left = headlen + bodylen - n;
	if (fread(out + n, 1, left, fp) != left)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 
		
	ok = 1;

end:
	if (!ok && out) OPENSSL_free(out);
	
	*len = headlen + bodylen;
	return out; 
}

int CPK_key_detachdecrypt(const char *keyfile, const char *pass,
		const char *infile, const char *outfile, int flag)
{
	int ret = 0;	

	PRIVKEY *privkey = NULL;
	RCPTINFO *rcptinfo = NULL;	
	unsigned char *outbuf = NULL;
	unsigned int outlen;
	FILE *infp = NULL;
	FILE *outfp = NULL;


	if (!keyfile)
	{	
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(privkey = CPK_read_keyfile(keyfile, pass, flag)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}
	
	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, outfile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (!(rcptinfo = CPK_read_encfp(infp?infp:stdin, flag)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!PRIVKEY_decrypt(privkey, rcptinfo, NULL, &outlen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	if (!(outbuf = (unsigned char *)OPENSSL_malloc(outlen)))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}
	
	if (!PRIVKEY_decrypt(privkey, rcptinfo, outbuf, &outlen))
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	} 
	
	if (fwrite(outbuf, 1, outlen, outfp?outfp:stdout) != outlen)
	{
		fprintf(stderr, "%s(%d):", __FILE__, __LINE__);
		goto end;
	}

	ret = 1;

end:
	if (privkey) PRIVKEY_free(privkey);
	if (rcptinfo) RCPTINFO_free(rcptinfo);
	if (outbuf) OPENSSL_free(outbuf);
	
	return ret;
}

int CPK_id2pubkey_fp(FILE *infp, const char *id, FILE *outfp)
{
	int ret = 0;
	BN_CTX *ctx = NULL;
	EC_KEY *eckey = NULL;
	MATRIX *matrix = NULL;
	
	if (!(ctx = BN_CTX_new()))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}	

	if (!(matrix = CPK_read_matfp(infp, 0)))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}
	
	if (!(eckey = PUBMATRIX_get_eckey(matrix, id, strlen(id))))
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	fprintf(outfp, "%s\n", EC_POINT_point2hex(EC_KEY_get0_group(eckey),
		EC_KEY_get0_public_key(eckey), 4, ctx));

	ret = 1;
end:
	if (ctx) BN_CTX_free(ctx);
	if (eckey) EC_KEY_free(eckey);
	if (matrix) MATRIX_free(matrix);
	return ret;	
}

int CPK_id2pubkey_file(const char *infile, const char *id, const char *outfile)
{
	int ret = 0;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	if (infile)
	{
		if (!(infp = fopen(infile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, infile, __FILE__, __LINE__);
			goto end;
		}
	}

	if (outfile)
	{
		if (!(outfp = fopen(outfile, "wb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, outfile, __FILE__, __LINE__);
			goto end;
		}
	}

	ret = CPK_id2pubkey_fp(infp?infp:stdin, id, outfp?outfp:stdout);

end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);
	return ret;
}

const char *CPK_read_pass(char *passbuf, unsigned int buflen, const char *pass, const char *passfile)
{
	int len;
	FILE *fp = NULL;

	if (pass)
		return pass;

	if (passfile)
	{
		if (!(fp = fopen(passfile, "rb")))
		{
			fprintf(stderr, STR_ERROR_OPENFILE, passfile, __FILE__, __LINE__);
			return NULL;
		}
		
		if ((len = fread(passbuf, 1, buflen, fp)) <= 0)
		{
			fprintf(stderr, STR_ERROR_READFILE, passfile, __FILE__, __LINE__);
			fclose(fp);
			return NULL;
		}
	
		passbuf[len - 1] = 0;	
		fclose(fp);
		return passbuf;
	}

	return NULL;
}
// outer main



// CPK Config
char *conf_keyfile = NULL;
char *conf_matfile = NULL;
const char *conf_signalgo = "SHA1";
const char *conf_outform = "RAW";
const char *conf_ec = "secp192k1";
int conf_matrix_col = 32;
int conf_matrix_row = 32;
const char * conf_mapalgo = "SHA1";
const char *conf_kdfalgo = "SHA1";
const char *conf_encalgo = "AES-128-CBC";
const char *conf_macalgo = "SHA1";


#define ERR_STR_OPEN_FILE "open file %s failed:\n"

/**
 * --detach           -
 * --armor            -
 * --key arg          -
 * --signer arg       -
 * --key-pass arg     -
 * --sign-algo arg    -
 * --append-to arg    -
 * --in arg           -
 * --outform arg      -
 * --out arg          -
 */
#define CPK_MAX_PASSWORD_LEN	512


// ----- MAIN BEGIN -----------------------------------------------------------

#define STR_USAGE_GENPRIMAT	"cpk gen-secmatrix [--ec name] --col num --row num [--map-algo name] [--out file]\n"
#define STR_ERROR_GENPRIMAT	"private matrix generation failed\n"
int MAIN_gen_privmatrix(int argc, char *argv[])
{
	int ret = 1;

	const char *ec = NULL;
	int col = 0;
	int row = 0;
	const char *map = NULL;
	char *outfile = NULL;
	FILE *outfp = NULL;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--ec") == 0)
		{
			if (--argc < 1) goto bad;
			ec = *(++argv);
			
			if (!CPK_ecname_is_valid(ec))
			{
				fprintf(stderr, "invalid elliptic curve `%s'\n", ec);
				goto end;
			}
		}
		else if (strcmp(*argv, "--col") == 0)
		{
			if (--argc < 1) goto bad;
			col = atoi( *(++argv) );

			if (col <= 0)
			{
				fprintf(stderr, "invalid column size %s\n", *argv);
				goto end;
			}
		}
		else if (strcmp(*argv, "--row") == 0)
		{
			if (--argc < 1) goto bad;
			row = atoi( *(++argv) );
		
			if (row <= 0)
			{	
				fprintf(stderr, "invalid row size %s\n", *argv);
				goto end;
			}
		}
		else if (strcmp(*argv, "--map-algo") == 0)
		{
			if (--argc < 1) goto bad;
			map = *(++argv);
			
			if (!CPK_mapalgo_is_valid(map))
			{
				fprintf(stderr, "invalid map algorithm %s\n", map);
				goto end;
			}
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
	
			if (!(outfp = fopen(outfile, "wb")))
			{
				fprintf(stderr, "open file '%s' failed\n", outfp);	
				goto end;
			}
		}
		else 
		{
			fprintf(stderr, "invalid option %s\n", *argv);
bad:
			fprintf(stderr, "usage: cpk gen-secmatrix [--ec name] ");
			fprintf(stderr, "--col num --row num [--map-algo name] [--out file]\n");
			
			goto end;
		} 
		
		argc--;
		argv++;
	}


	if (!ec) ec = conf_ec;
	if (col <= 0) goto bad;
	if (row <= 0) goto bad;
	if (!map) goto bad;
	
	// TOFIX:  check col-row-map is valid
	
	if (!CPK_gen_privmatrix(ec, col, row, map, outfp?outfp:stdout))
	{
		fprintf(stderr, "cpk gen-secmatrix failed\n");
		goto end;
	}			

	ret = 0;

end:
	if (outfp) fclose(outfp);

	return ret;
}

#define STR_ERROR_GENPUBMAT	"public matrix generation failed\n"
#define STR_USAGE_GENPUBMAT	"cpk gen-pub-matrix [--in private-matrix-file] [--out file]\n"
int MAIN_gen_pubmatrix(int argc, char *argv[])
{
	int ret = 1;

	char *infile = NULL;
	char *outfile = NULL;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		
			if (!(infp = fopen(infile, "rb")))
			{
				fprintf(stderr, "open file %s failed\n", infile);
				goto end;
			}
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);

			if (!(outfp = fopen(outfile, "wb")))
			{
				fprintf(stderr, "open file %s failed\n", outfile);
				goto end;
			}
		}
		else 
		{
			fprintf(stderr, "option %s invalid\n", *argv);
bad:
			fprintf(stderr, "usage: cpk gen-pub-matrix [--in private-matrix-file] [--out file]\n");
			goto end;
		}

		argc--;
		argv++;
	}

	if (!CPK_gen_pubmatrix(infp?infp:stdin, outfp?outfp:stdout))
	{
		fprintf(stderr, "cpk gen-pub-matrix failed\n");
		goto end;
	}

	ret = 0;

end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);

	return ret;
}

#define STR_USAGE_GEN_PRIVKEY "cpk gen-key --id id [--in matrix-file] [--out file]\n"
int MAIN_gen_privkey(int argc, char *argv[])
{
	int ret = 1;
	
	char *id = NULL;
	char *infile = NULL;
	char *outfile = NULL;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	argc--;	
	argv++;
	while (argc >=1)
	{
		if (strcmp(*argv, "--id") == 0)
		{
			if (--argc < 1) goto bad;
			id = *(++argv);
		}
		else if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		
			if (!(infp = fopen(infile, "rb")))
			{
				fprintf(stderr, "open file %s failed\n", infile);
				goto end;
			}
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
			
			if (!(outfp = fopen(outfile, "wb")))
			{
				fprintf(stderr, "open file %s failed\n", outfile);
				goto end;
			}
		}
		else 
		{
			fprintf(stderr, "option %s invalid\n", *argv);
bad:
			fprintf(stderr, STR_USAGE_GEN_PRIVKEY);
			goto end;
		}

		argc--;
		argv++;
	}

	if (!id) goto bad;	
				
	
	if (!CPK_gen_privkey(infp?infp:stdin, id, outfp?outfp:stdout))
	{
		fprintf(stderr, "gen private key failed\n");
		goto end;
	}

	ret = 0;

end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);

	return ret;
}


#define STR_USAGE_ID2PUBKEY	"cpk id2pubkey --id id [--in file] [--out file]\n"
#define STR_ERROR_ID2PUBKEY	"get public key from matrix failed\n"

int MAIN_id2pubkey(int argc, char *argv[])
{
	int ret = 1;

	char *id = NULL;
	char *infile = NULL;
	char *outfile = NULL;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	argc--;	
	argv++;
	while (argc >=1)
	{
		if (strcmp(*argv, "--id") == 0)
		{
			if (--argc < 1) goto bad;
			id = *(++argv);
		}
		else if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
			
		}	
		else 
		{
			fprintf(stderr, "option %s invalid\n", *argv);
bad:
			fprintf(stderr, STR_USAGE_ID2PUBKEY);
			goto end;
		}

		argc--;
		argv++;
	}

	if (!id) goto bad;
	
	if (!CPK_id2pubkey_file(infile, id, outfile))
	{
		fprintf(stderr, STR_ERROR_ID2PUBKEY);
	}

	

end:
	if (infp) fclose(infp);
	if (outfp) fclose(outfp);

	return ret;
}

void CPK_help_print_spaces(FILE *fp, unsigned int len)
{
	int i;
	for (i=0; i<len; i++)
		fprintf(fp, " ");
}


void CPK_help_print_detachsign(FILE *outfp, const char *header)
{
	const char *h = header;

	fprintf(outfp, "%s [[--key file] | [--token dev]] [--signer id] [--sign-algo name]\n", h);
	CPK_help_print_spaces(outfp, strlen(h));
	fprintf(outfp, " [--pass pass] [--passfile file] [--in file] [--outform name]\n", h);
	CPK_help_print_spaces(outfp, strlen(h));
	fprintf(outfp, " [--armor] [--out file]\n", h);
} 
	

int MAIN_sign(int argc, char *argv[])
{
	int ret = 1;

	int detach = 0;
	int armor = 0;
	const char *keyfile = NULL;
	const char *dev = NULL;
	const char *pass = NULL;
	char *passfile = NULL;
	const char *signalgo = conf_signalgo;
	char *infile = NULL;
	char *outform = NULL;
	char *outfile = NULL;

	char passbuf[512];
	unsigned int passbuflen = 512;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--detach") == 0)
		{
			detach = 1;
		}
		else if (strcmp(*argv, "--key") == 0)
		{
			if (--argc < 1) goto bad;
			keyfile = *(++argv);
		}
		else if (strcmp(*argv, "--token") == 0)
		{
			if (--argc < 1) goto bad;
			dev = *(++argv);
		}
		else if (strcmp(*argv, "--pass") == 0)
		{
			if (--argc < 1) goto bad;
			pass = *(++argv);
		}
		else if (strcmp(*argv, "--passfile") == 0)
		{
			if (--argc < 1) goto bad;
			passfile = *(++argv);
		}
		else if (strcmp(*argv, "--sign-algo") == 0)
		{
			if (--argc < 1) goto bad;
			signalgo = *(++argv);	
		}
		else if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		}
		else if (strcmp(*argv, "--armor") == 0)
		{
			armor = 1;
		}
		else if (strcmp(*argv, "--outform") == 0)
		{
			if (--argc < 1) goto bad;
			outform = *(++argv);
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
		}
		else 
		{
			fprintf(stderr, STR_ERROR_OPTION, *argv);
bad:
			CPK_help_print_detachsign(stderr, "cpk sign");
			goto end;
		}
		
		argc--;	
		argv++;
	}

	// set defaults
	//if (!keyfile && !dev)
	//{
	//	if (!(dev = TOKEN_default_dev()))
	//	{
	//		keyfile = conf_keyfile;
	//	}
	//}

	pass = CPK_read_pass(passbuf, passbuflen, pass, passfile);

	if (!CPK_signalgo_is_valid(signalgo))
	{
		fprintf(stderr, "sign-algorithm %s invalid\n", signalgo);
		goto end;
	}
	
	if (dev)
	{
		printf("CPK_token_sign() %s %d\n", __FILE__, __LINE__);
		//CPK_token_sign();
	}
	else if (keyfile)
	{
		if (!CPK_key_sign(keyfile, pass, signalgo, infile, outfile, 0))
		{
			fprintf(stderr, STR_ERROR_FILELINE":failed\n", __FILE__, __LINE__);
			goto end;
		}
	}
	else 
	{	
		fprintf(stderr, "you must plug a token or have a keyfile "STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}

	ret = 0;
end:

	return ret;
}
	
		
/* 
 * cpk sign [--detach] [--armor] [--key file [--key-pass arg] | --token dev] [--sign-algo name]
 * 	    [--append-to sigfile] [--in signedfile] [--outform name] [--out file]
 */


char *CPK_remove_file_exname(char *buf, unsigned int len, const char *filename)
{
	int i;

	if (strlen(filename) > len - 1)
		return NULL;
	
	strcpy(buf, filename);

	for (i=strlen(filename)-1; i>=0; i--)
	{
		if (buf[i] == '.')
		{
			buf[i] = 0;
			return buf;
		}
	}
	
	return NULL;
}

#define CPK_TYPE_SIGFULL	1
int CPK_filetype(const char *filename)
{
	return 0;
}

/*
 cpk verify --matrix file [--sig-file file] [--signed-file file]
*/
int MAIN_verify(int argc, char *argv[])
{
	int ret = 1;
	

	FILE *sigfp = NULL;
	FILE *matfp = NULL;
	FILE *signedfp = NULL;
	char *matrixfile = NULL;
	const char *sigfile = NULL;
	char *signedfile = NULL;
	int badops = 0;
	char *prog = *argv;

	unsigned int def_signedfilelen = 512;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--matrix") == 0)
		{
			if (--argc < 1) goto bad;
			matrixfile = *(++argv);
		}
		else if (strcmp(*argv, "--sig-file") == 0)
		{
			if (--argc < 1) goto bad;
			sigfile = *(++argv);
		}
		else if (strcmp(*argv, "--signed-file") == 0)
		{
			if (--argc < 1) goto bad;
			signedfile = *(++argv);
		}
		else 
		{
			fprintf(stderr, STR_ERROR_OPTION, *argv);
bad:
			fprintf(stderr, "usage:\n");
			fprintf(stderr, "cpk verify [--matrix file] [--sig-file file] [--signed-file file]\n");
			goto end;
		}
		
		argc--;
		argv++;
	}		
	
	if (!sigfile)
	{
		if (signedfile)
		{
			fprintf(stderr, "require option --sig-file\n");
			goto bad;
		}
		
		// read SignedData from stdin
		printf("Error: CPK_verify() not implemented %s %d\n", __FILE__, __LINE__);
		goto end;	
	}
	else if (CPK_filetype(sigfile) == CPK_TYPE_SIGFULL)
	{
		printf("Error: CPK_verify() not implemented %s %d\n", __FILE__, __LINE__);
		goto end;	
	}
	else if (!signedfile)
	{
	/*
		def_signedfile = 
			CPK_remove_file_exname(
			def_signedfile, 
			def_signedfilelen, 
			sigfile);

		if (fileexist(def_signedfile))
			signedfile = def_signedfile;
	*/
	}
	
	
	if (!CPK_detachverify(matrixfile, signedfile, sigfile, 0))
	{
		fprintf(stderr, "verify failed\n");
		goto end;
	}
	else 
	{
		fprintf(stdout, "Verify success: ");
		CPK_parse_sigfile(sigfile, NULL, 0);
	}	
end:
	return 0;
}

// encrypt [--detach] [--armor] [--matrix file] --recipient id 
//	   [--kdf-algo name][--enc-algo name] [--mac-algo name]
//	   [--in file] [--out file] 
int MAIN_encrypt(int argc, char *argv[])
{
	int ret = 1;

	int detach = 0;
	int armor = 0;
	const char *matrixfile = conf_matfile;
	const char *rcptid = NULL;
	const char *kdfalgo = conf_kdfalgo;
	const char *encalgo = conf_encalgo;
	const char *macalgo = conf_macalgo;
	const char *infile = NULL;	
	const char *outfile = NULL;
	FILE *infp = NULL;
	FILE *outfp = NULL;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--detach") == 0)
		{
			detach = 1;
		}
		else if (strcmp(*argv, "--armor") == 0)
		{
			armor = 1;
		}
		else if (strcmp(*argv, "--matrix") == 0)
		{
			if (--argc < 1) goto bad;
			matrixfile = *(++argv);
		}
		else if (strcmp(*argv, "--recipient") == 0)
		{
			if (--argc < 1) goto bad;
			rcptid = *(++argv);
		}
		else if (strcmp(*argv, "--kdf-algo") == 0)
		{
			if (--argc < 1) goto bad;
			kdfalgo = *(++argv);
		}
		else if (strcmp(*argv, "--enc-algo") == 0)
		{
			if (--argc < 1) goto bad;
			encalgo = *(++argv);
		}
		else if (strcmp(*argv, "--mac-algo") == 0)
		{
			if (--argc < 1) goto bad;
			macalgo = *(++argv);
		}	
		else if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
		}
		else 
		{
			fprintf(stderr, STR_ERROR_OPTION, *argv);
bad:
			fprintf(stderr, "cpk encrypt usage:\n");
			fprintf(stderr, "cpk encrypt [--detach] [--armor] [--matrix file] --recipient id\n");
			fprintf(stderr, "            [--kdf-algo name] [--enc-algo name] [--mac-algo name]\n");
			fprintf(stderr, "            [--in file] [--out file]\n");
			goto end; 
		}

		argc--;
		argv++;
	}

	if (!rcptid)
	{
		fprintf(stderr, "require otpion --recipient\n");
		goto end;
	}

	if (!matrixfile || !kdfalgo || !encalgo || !macalgo)
	{
		fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
		goto end;
	}	

	if (!detach)
	{
		printf("ERROR: CPK_encrypt() not implement, use --detach\n");
		goto end;
	}

	CPK_detachencrypt(matrixfile, rcptid, kdfalgo, encalgo, macalgo, infile, outfile, 0);

	ret = 0;
end:
	return ret;
}


// cpk decrypt [[--key file] | [--token dev]] [--id id] [--pass pass] [--passfile file] 
//             [--in file] [--out file]
int MAIN_decrypt(int argc, char *argv[])
{
	int ret = 1;

	const char *keyfile = NULL;
	const char *dev = NULL;
	const char *id = NULL;
	const char *pass = NULL;
	const char *passfile = NULL;
	const char *infile = NULL;
	const char *outfile = NULL;
	FILE *infp = NULL;
	FILE *outfp = NULL;
	unsigned int passbuflen = 512;
	int flag = 0;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--key") == 0)
		{
			if (--argc < 1) goto bad;
			keyfile = *(++argv);
		}
		//else if (strcmp(*argv, "--token") == 0)
		//{
		//	if (--argc < 1) goto bad;
		//	dev = *(++argv);
		//}
		else if (strcmp(*argv, "--id") == 0)
		{
			if (--argc < 1) goto bad;
			id = *(++argv);
		}
		else if (strcmp(*argv, "--pass") == 0)
		{
			if (--argc < 1) goto bad;
			pass = *(++argv);
		}
		else if (strcmp(*argv, "--passfile") == 0)
		{
			if (--argc < 1) goto bad;
			passfile = *(++argv);
		}
		else if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
		}
		else 
		{
			fprintf(stderr, STR_ERROR_OPTION, *argv);
bad:
			fprintf(stderr, "cpk decrypt usage:\n");
			fprintf(stderr, "cpk decrypt [[--key file] | [--token dev]] [--id id] [--pass pass]\n");
			fprintf(stderr, "            [--passfile file] [--in file] [--out file]\n");			
			goto end;
		}
	
		argc--;
		argv++;
	}

	if (dev)
	{
		fprintf(stderr, "ERROR: CPK_token_decrypt() not implement %s %d\n", __FILE__, __LINE__);
		goto end;
	}
	else if (keyfile)
	{
		if (!CPK_key_detachdecrypt(keyfile, pass, infile, outfile, flag))
		{
			fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
			goto end;
		}
	}
	//else if (TOKEN_default_dev())
	//{
	//	fprintf(stderr, "ERROR: CPK_token_decrypt() not implement %s %d\n", __FILE__, __LINE__);
	//	goto end;
	//}
	else if ((keyfile = conf_keyfile) != NULL)
	{
		if (!CPK_key_detachdecrypt(keyfile, pass, infile, outfile, flag))
		{
			fprintf(stderr, STR_ERROR_FILELINE, __FILE__, __LINE__);
			goto end;
		}
	}

end:	
	return ret;	
}

void CPK_help_print_cmds(FILE *outfp, const char *lineheader)
{
	const char *h = lineheader?lineheader:"";

	fprintf(outfp, "%s gen-secmatrix      - generate private matrix\n", h);
	fprintf(outfp, "%s gen-key            - generate private key from a private matrix\n", h);
	fprintf(outfp, "%s gen-pubmatrix      - derive public matrix from a private matrix\n", h);
	fprintf(outfp, "%s id2pubkey          - print a give ID's public key\n", h);
	
	fprintf(outfp, "%s detach-sign        - make a detached signature\n", h);
	fprintf(outfp, "%s sign               - make a signature\n", h);
	fprintf(outfp, "%s verify             - verify a signature\n", h);
	fprintf(outfp, "%s encrypt            - encrypt data\n", h);
	fprintf(outfp, "%s decrypt            - decrypt data\n", h);
	fprintf(outfp, "%s parse              - parse cpk structure\n", h);
	fprintf(outfp, "%s help               - help\n", h);
}

char *CPK_help_usage_string(const char *cmd)
{
	return "not-implemented\n";
}


int MAIN_help(int argc, char *argv[])
{

	static const char *help = 
	"cpk " RELEASE_VERSION "  " RELEASE_TIME "\n"
	"Copyright 2006 (C) www.guanzhi.org\n"
	"\n"
	"Home: ~/.cpk\n"
	"Pubkey: ECDSA, ECIES\n" 
	"Cipher: 3DES, CAST5, BLOWFISH, AES128, AES192, AES256, TWOFISH\n"
	"Hash: MD5, SHA1, RIPEMD160, SHA256\n"
	"\n"
	"Syntax: cpk command [options]\n"
	"\n"
	"	cpk sign    [--detach]  [--key file | --token dev]  [--keyid id] [--sign-algo name]\n"
	"		    [--armor] [--in file] [--append-to file] [--outform name] [--out file]\n"
	"	cpk verfiy  [options]\n"	
	"	cpk encrypt [options]\n"
	"	cpk decrypt [options]\n"
	"	cpk parse   [--inform name] [--in file] [--out file]\n"
	"	cpk help    [name]\n"
	"\n"
	"Commands:\n"
 	"\n"
	"\n"
	"Options:\n"
 	"\n"
	"	--key file		PrivateKey file\n"
	"	--sign-algo name	\n"
	"	--append-to file	\n"
	"	--in file		\n"
	"	--out file		\n"
	"\n"
	"(See the man page for a complete listing of all commands and options)\n"
	"\n"	
	"Examples:\n"
	"\n"
	"	cpk gen-secmatrix --ec secp192k1 --col 32 --row 32 --map-algo SHA1 --out matrix.skm\n"
	"	cpk gen-pubmatrix --in matrix.skm --out matrix.pkm\n"
	"	cpk gen-key --id yourname --in matrix.skm > yourname.skey\n"
	"	cpk sign --key yourname.skey --in document.txt > document.txt.sig\n"
	"	cpk verify --matrix matrix.pkm --signed-file document.txt --sig-file document.txt.sig\n"
	"	echo a-session-key | cpk encrypt --detach --matrix matrix.pkm --recipient rcpt-name > symmkey.cpk\n"
	"	cpk decrypt --key yourname.skey --in cipher.cpk > plain\n"
	"\n";
	

	fprintf(stdout, help);

	return 0;

}

// cpk parse [--type name] [--in file] [--out file]
int MAIN_parse(int argc, char *argv[])
{
	int ret = 1;
	int badopt = 0;

	char *type = NULL;
	char *inform = "DER";
	char *infile = NULL;
	char *outfile = NULL;
	FILE *infp = stdin;
	FILE *outfp = stdout;

	argc--;
	argv++;
	while (argc >= 1)
	{
		if (strcmp(*argv, "--type") == 0)
		{
			if (--argc < 1) goto bad;
			type = *(++argv);
		}
		else if (strcmp(*argv, "--inform") == 0)
		{
			if (--argc < 1) goto bad;
			inform = *(++argv);
		}
		else if (strcmp(*argv, "--in") == 0)
		{
			if (--argc < 1) goto bad;
			infile = *(++argv);
		}
		else if (strcmp(*argv, "--out") == 0)
		{
			if (--argc < 1) goto bad;
			outfile = *(++argv);
		}
		else 
		{
			fprintf(stderr, "cpk: invalid option %s\n", *argv);
			goto usage;
		}
	
		argc--;
		argv++;
	}
		
	if (badopt)
	{
bad:
usage:
		fprintf(stderr, "cpk: usage: cpk parse [--type name] [--inform name] [--in file] [--out file]\n");
		fprintf(stderr, "Supported type name: PrivateKey, PublicMatrix, PrivateMatrix, SignerInfo, RecipientInfo\n");
		fprintf(stderr, "Supported inform name: DER, TXT\n");
		goto end;	
	}

	

	if (!strcmp(inform, "DER") && !strcmp(inform, "TXT"))
	{
		fprintf(stderr, "unknown --inform '%s'\n", inform);
		goto usage;
	}		

	// do parse
	if (!type)
	{
		fprintf(stderr, "require option --type name\n");
		goto end;
	}

	if (strcmp(type, "PrivateKey") == 0) {
		ret = CPK_parse_keyfile(infile, NULL, outfile, 0);
	}		
	else if (strcmp(type, "PrivateMatrix") == 0) {
		ret = CPK_parse_matfile(infile, outfile, 1);
	}		
	else if (strcmp(type, "PublicMatrix") == 0) {
		ret = CPK_parse_matfile(infile, outfile, 0);
	}		
	else if (strcmp(type, "SignerInfo") == 0) {
		ret = CPK_parse_sigfile(infile, outfile, 0);
	}		
	else if (strcmp(type, "RecipientInfo") == 0) {
		ret = CPK_parse_encfile(infile, outfile, 0);
	}		
	else {
		fprintf(stderr, "unknown --type '%s'\n", type);
		goto usage;
	}

	if (!ret)
	{
		fprintf(stderr, "cpk parse %s failed\n", type);
	}


	
end:
	// TOFIX: fclose() lead to Segment Failt
	//if (infile && infp) fclose(infp); 
	//if (outfile && outfp) fclose(outfp);

	
	return !ret;
}

int MAIN_version(int argc, char *argv[])
{
	fprintf(stdout, "cpk  %s (%s) %s %s\n", 
		RELEASE_VERSION, DEVELOP_VERSION, RELEASE_TIME, OPENSSL_VERSION);

	return 0;
}

int main(int argc, char *argv[])
{
	int ret = 1;
	char *cmd;

	//CPK_init_conf();
	ERR_load_crypto_strings();


	if (argc < 2)
	{
usage:
		fprintf(stderr, "cpk usage:\n");
		CPK_help_print_cmds(stderr, "  ");
		fprintf(stderr, "\n");
		fprintf(stderr, "Try `cpk help [command]' for more information.\n");
		return 0;
	}

	cmd = argv[1];

	argc--;
	argv++;
	if (strcmp(cmd, "quit") == 0)
	{
		ret = 0;
		goto end;
	}
	else if (strcmp(cmd, "exit") == 0)
	{
		ret = 0;
		goto end;
	}
	else if (strcmp(cmd, "help") == 0)
	{
		return MAIN_help(argc, argv);
	}
	else if (strcmp(cmd, "gen-secmatrix") == 0)
	{
		return MAIN_gen_privmatrix(argc, argv);
	}
	else if (strcmp(cmd, "gen-pubmatrix") == 0)
	{
		return MAIN_gen_pubmatrix(argc, argv);
	}
	else if (strcmp(cmd, "gen-key") == 0)
	{
		return MAIN_gen_privkey(argc, argv);
	}
	else if (strcmp(cmd, "id2pubkey") == 0)
	{
		return MAIN_id2pubkey(argc, argv);
	}
	else if (strcmp(cmd, "sign") == 0)
	{
		return MAIN_sign(argc, argv);
	}
	else if (strcmp(cmd, "encrypt") == 0)
	{
		return MAIN_encrypt(argc, argv);
	}
	else if (strcmp(cmd, "verify") == 0)
	{
		return MAIN_verify(argc, argv);
	}
	else if (strcmp(cmd, "decrypt") == 0)
	{
		return MAIN_decrypt(argc, argv);
	}
	else if (strcmp(cmd, "parse") == 0)
	{
		return MAIN_parse(argc, argv);
	}
	else if (strcmp(cmd, "version") == 0)
	{
		return MAIN_version(argc, argv);
	}
	else 
	{
		goto usage;		
	}	
	
	ret = 0;

end:	
	return ret;	
}
